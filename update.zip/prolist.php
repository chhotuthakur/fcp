<?php
ob_start();
include 'header.php';
include 'partials/_categories_img_nav.php';
?>



<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>.
    <link rel="stylesheet" href="assets/css/flip.css">
</head>
<body>
    





<div class="_36fx1h _6t1WkM _3HqJxg">
    <div class="_1YokD2 _2GoDe3">
        <div class="_1YokD2 _3Mn1Gg col-2-12" style="flex: 0 0 280px; max-width: 280px; padding: 0px 10px 0px 0px;">
            <div class="_1AtVbE col-12-12" style="padding: 0px 0px 10px;"><a href="/6bo/g0i/9no/~cs-2sui29twwl/pr?sid=6bo%2Cg0i%2C9no&amp;collection-tab-name=+Newly+Launched+Monitors&amp;param=1234&amp;ctx=eyJjYXJkQ29udGV4dCI6eyJhdHRyaWJ1dGVzIjp7InRpdGxlIjp7Im11bHRpVmFsdWVkQXR0cmlidXRlIjp7ImtleSI6InRpdGxlIiwiaW5mZXJlbmNlVHlwZSI6IlRJVExFIiwidmFsdWVzIjpbIk5ldyBSYW5nZSBvZiBNb25pdG9ycyJdLCJ2YWx1ZVR5cGUiOiJNVUxUSV9WQUxVRUQifX19fX0%3D&amp;nnc=29DGAM186JVI_MERCH&amp;otracker=bp_browse_announcement_6bo%2Cg0i%2C9no" class="UYS4aW _3E_YdP" data-tkid="M_1b8fc128-3ded-45c7-b3cc-226d6112e9f0_4.29DGAM186JVI">
                    <div class="_3ywSr_" style="padding-top: 53.57%;">
                        <div class="_1bEAQy _2iN8uD _312yBx" style="padding-top: 53.57%;"><img class="_2OHU_q _2WCh1J aA9eLq" alt="App" src="https://rukminim1.flixcart.com/fk-p-flap/400/400/image/3aa8e62cd04d4596.jpg?q=50"><img class="kJjFO0 _3DIhEh _9JTfqZ" src="https://rukminim1.flixcart.com/fk-p-flap/100/100/image/3aa8e62cd04d4596.jpg?q=50" alt="App"></div>
                    </div>
                    <div class="_1sPNy4">
                        <div class="_2LR_KO">Sale is Live</div>
                        <div class="tMzY0d">Sale is Live From ₹5,499</div>
                    </div>
                </a></div>
            <div class="_1YokD2 _3Mn1Gg col-12-12">
                <div class="_1AtVbE col-12-12">
                    <div class="_1KOcBL">
                        <section class="JWMl0H _2hbLCH">
                            <div class="_2ssEMF">
                                <div class="_3V8rao"><span>Filters</span></div>
                            </div>
                        </section>
                        <div class="_2q_g77">
                            <section class="_2aDURW">
                                <div class="_2lfNTw"><span>CATEGORIES</span></div>
                                <div>
                                    <div class="TB_InB"><span><svg width="10" height="10" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="_2Iqv73">
                                                <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="_3zK8He"></path>
                                            </svg></span><a class="_2qvBBJ _2Mji8F" title="Computers" href="/computers/pr?sid=6bo&amp;otracker=categorytree">Computers</a></div>
                                </div>
                                <div>
                                    <div class="TB_InB"><span><svg width="10" height="10" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="_2Iqv73">
                                                <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="_3zK8He"></path>
                                            </svg></span><a class="_2qvBBJ _2Mji8F" title="Computer Components" href="/computers/computer-components/pr?sid=6bo,g0i&amp;otracker=categorytree">Computer Components</a></div>
                                </div>
                                <div>
                                    <div class="TB_InB"><span><svg width="10" height="10" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="_2Iqv73">
                                                <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class=""></path>
                                            </svg></span><a class="_1jJQdf _2Mji8F" title="Monitors" href="/computers/computer-components/monitors/pr?sid=6bo,g0i,9no&amp;otracker=categorytree">Monitors</a></div>
                                </div>
                            </section>
                        </div>
                        <section class="_2yz7eI _2hbLCH">
                            <div class="_3KxRU6 _2ssEMF">
                                <div class="UR1L2I _3V8rao"><span>Price</span></div>
                            </div>
                            <div class="_2NBiOm">
                                <div class="_1nneZ0">
                                    <div class="_2TbXIJ" style="height: 5px; width: 59.2025px;"></div>
                                    <div class="_2TbXIJ" style="height: 25px; width: 59.2025px;"></div>
                                    <div class="_2TbXIJ" style="height: 15px; width: 59.2025px;"></div>
                                    <div class="_2TbXIJ" style="height: 5px; width: 59.2025px;"></div>
                                </div>
                            </div>
                            <div class="_2r34SG">
                                <div class="_12FhcQ">
                                    <div class="_31Kbhn _28DFQy" style="transform: translateX(0px);">
                                        <div class="_3FdLqY"></div>
                                    </div>
                                    <div class="_31Kbhn WC_zGJ" style="transform: translateX(-1.19px);">
                                        <div class="_3FdLqY"></div>
                                    </div>
                                    <div class="_2IN3-t"></div>
                                    <div class="_2IN3-t _1mRwrD" style="transform: translate(0px) scaleX(0.995);"></div>
                                </div>
                                <div class="_15GU70">
                                    <div class="_1ftpgI" style="width: 19.7342px;">.</div>
                                    <div class="_1ftpgI" style="width: 19.7342px;">.</div>
                                    <div class="_1ftpgI" style="width: 19.7342px;">.</div>
                                    <div class="_1ftpgI" style="width: 19.7342px;">.</div>
                                    <div class="_1ftpgI" style="width: 19.7342px;">.</div>
                                    <div class="_1ftpgI" style="width: 19.7342px;">.</div>
                                    <div class="_1ftpgI" style="width: 19.7342px;">.</div>
                                    <div class="_1ftpgI" style="width: 19.7342px;">.</div>
                                    <div class="_1ftpgI" style="width: 19.7342px;">.</div>
                                    <div class="_1ftpgI" style="width: 19.7342px;">.</div>
                                    <div class="_1ftpgI" style="width: 19.7342px;">.</div>
                                    <div class="_1ftpgI" style="width: 19.7342px;">.</div>
                                    <div class="_1ftpgI" style="width: 0px;">.</div>
                                </div>
                            </div>
                            <div class="_2b0bUo">
                                <div class="_1YAKP4"><select class="_2YxCDZ">
                                        <option value="Min" class="_3AsjWR">Min</option>
                                        <option value="250" class="_3AsjWR">250</option>
                                        <option value="500" class="_3AsjWR">500</option>
                                        <option value="1000" class="_3AsjWR">1000</option>
                                        <option value="2000" class="_3AsjWR">2000</option>
                                        <option value="5000" class="_3AsjWR">5000</option>
                                        <option value="10000" class="_3AsjWR">10000</option>
                                        <option value="20000" class="_3AsjWR">20000</option>
                                        <option value="30000" class="_3AsjWR">30000</option>
                                        <option value="40000" class="_3AsjWR">40000</option>
                                        <option value="50000" class="_3AsjWR">50000</option>
                                        <option value="60000" class="_3AsjWR">60000</option>
                                    </select></div>
                                <div class="_3zohzR">to</div>
                                <div class="_3uDYxP"><select class="_2YxCDZ">
                                        <option value="250" class="_3AsjWR">250</option>
                                        <option value="500" class="_3AsjWR">500</option>
                                        <option value="1000" class="_3AsjWR">1000</option>
                                        <option value="2000" class="_3AsjWR">2000</option>
                                        <option value="5000" class="_3AsjWR">5000</option>
                                        <option value="10000" class="_3AsjWR">10000</option>
                                        <option value="20000" class="_3AsjWR">20000</option>
                                        <option value="30000" class="_3AsjWR">30000</option>
                                        <option value="40000" class="_3AsjWR">40000</option>
                                        <option value="50000" class="_3AsjWR">50000</option>
                                        <option value="60000" class="_3AsjWR">60000</option>
                                        <option value="Max" class="_3AsjWR">60000+</option>
                                    </select></div>
                            </div>
                        </section>
                        <section class="_2hbLCH _24gLJx"><label class="_2iDkf8 shbqsL"><input type="checkbox" class="_30VH1S" readonly="">
                                <div class="_24_Dny _3tCU7L"></div>
                                <div class="_3879cV">
                                    <div class="_3U-Vxu"><img height="21" src="//static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png" class="_3U-Vxu"></div>
                                </div>
                            </label>
                            <div class="Bv11UC"><span class="question">?</span></div>
                        </section>
                        <section class="_167Mu3 _2hbLCH">
                            <div class="_213eRC _2ssEMF">
                                <div class="_2gmUFU _3V8rao">Brand</div><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="ttx38n">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="IIvmWM"></path>
                                </svg>
                            </div>
                        </section>
                        <section class="_167Mu3 _2hbLCH">
                            <div class="_213eRC _2ssEMF">
                                <div class="_2gmUFU _3V8rao">Customer Ratings</div><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="ttx38n _3DyGEM">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="IIvmWM"></path>
                                </svg>
                            </div>
                            <div class="_3FPh42">
                                <div class="_2d0we9">
                                    <div class="_4921Z t0pPfW" title="4★ &amp; above">
                                        <div class="_1Y4Vhm _4FO7b6"><label class="_2iDkf8 t0pPfW"><input type="checkbox" class="_30VH1S" readonly="">
                                                <div class="_24_Dny"></div>
                                                <div class="_3879cV">4★ &amp; above</div>
                                            </label></div>
                                    </div>
                                    <div class="_4921Z t0pPfW" title="3★ &amp; above">
                                        <div class="_1Y4Vhm _4FO7b6"><label class="_2iDkf8 t0pPfW"><input type="checkbox" class="_30VH1S" readonly="">
                                                <div class="_24_Dny"></div>
                                                <div class="_3879cV">3★ &amp; above</div>
                                            </label></div>
                                    </div>
                                    <div class="_4921Z t0pPfW" title="2★ &amp; above">
                                        <div class="_1Y4Vhm _4FO7b6"><label class="_2iDkf8 t0pPfW"><input type="checkbox" class="_30VH1S" readonly="">
                                                <div class="_24_Dny"></div>
                                                <div class="_3879cV">2★ &amp; above</div>
                                            </label></div>
                                    </div>
                                    <div class="_4921Z t0pPfW" title="1★ &amp; above">
                                        <div class="_1Y4Vhm _4FO7b6"><label class="_2iDkf8 t0pPfW"><input type="checkbox" class="_30VH1S" readonly="">
                                                <div class="_24_Dny"></div>
                                                <div class="_3879cV">1★ &amp; above</div>
                                            </label></div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section class="_167Mu3 _2hbLCH">
                            <div class="_213eRC _2ssEMF">
                                <div class="_2gmUFU _3V8rao">Discount</div><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="ttx38n">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="IIvmWM"></path>
                                </svg>
                            </div>
                        </section>
                        <section class="_167Mu3 _2hbLCH">
                            <div class="_213eRC _2ssEMF">
                                <div class="_2gmUFU _3V8rao">Display Size</div><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="ttx38n">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="IIvmWM"></path>
                                </svg>
                            </div>
                        </section>
                        <section class="_167Mu3 _2hbLCH">
                            <div class="_213eRC _2ssEMF">
                                <div class="_2gmUFU _3V8rao">Screen Resolution</div><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="ttx38n">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="IIvmWM"></path>
                                </svg>
                            </div>
                        </section>
                        <section class="_167Mu3 _2hbLCH">
                            <div class="_213eRC _2ssEMF">
                                <div class="_2gmUFU _3V8rao">Screen Form Factor</div><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="ttx38n">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="IIvmWM"></path>
                                </svg>
                            </div>
                        </section>
                        <section class="_167Mu3 _2hbLCH">
                            <div class="_213eRC _2ssEMF">
                                <div class="_2gmUFU _3V8rao">Inbuilt Speaker</div><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="ttx38n">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="IIvmWM"></path>
                                </svg>
                            </div>
                        </section>
                        <section class="_167Mu3 _2hbLCH">
                            <div class="_213eRC _2ssEMF">
                                <div class="_2gmUFU _3V8rao">Panel Type</div><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="ttx38n">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="IIvmWM"></path>
                                </svg>
                            </div>
                        </section>
                        <section class="_167Mu3 _2hbLCH">
                            <div class="_213eRC _2ssEMF">
                                <div class="_2gmUFU _3V8rao">Connectivity</div><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="ttx38n">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="IIvmWM"></path>
                                </svg>
                            </div>
                        </section>
                        <section class="_167Mu3 _2hbLCH">
                            <div class="_213eRC _2ssEMF">
                                <div class="_2gmUFU _3V8rao">Suitable For</div><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="ttx38n">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="IIvmWM"></path>
                                </svg>
                            </div>
                        </section>
                        <section class="_167Mu3 _2hbLCH">
                            <div class="_213eRC _2ssEMF">
                                <div class="_2gmUFU _3V8rao">Response Time</div><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="ttx38n">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="IIvmWM"></path>
                                </svg>
                            </div>
                        </section>
                        <section class="_167Mu3 _2hbLCH">
                            <div class="_213eRC _2ssEMF">
                                <div class="_2gmUFU _3V8rao">Offers</div><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="ttx38n _3DyGEM">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="IIvmWM"></path>
                                </svg>
                            </div>
                            <div class="_3FPh42">
                                <div class="_2d0we9">
                                    <div class="_4921Z t0pPfW" title="No Cost EMI">
                                        <div class="_1Y4Vhm _4FO7b6"><label class="_2iDkf8 t0pPfW"><input type="checkbox" class="_30VH1S" readonly="">
                                                <div class="_24_Dny"></div>
                                                <div class="_3879cV">No Cost EMI</div>
                                            </label></div>
                                    </div>
                                    <div class="_4921Z t0pPfW" title="Special Price">
                                        <div class="_1Y4Vhm _4FO7b6"><label class="_2iDkf8 t0pPfW"><input type="checkbox" class="_30VH1S" readonly="">
                                                <div class="_24_Dny"></div>
                                                <div class="_3879cV">Special Price</div>
                                            </label></div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section class="_167Mu3 _2hbLCH">
                            <div class="_213eRC _2ssEMF">
                                <div class="_2gmUFU _3V8rao">GST Invoice Available</div><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="ttx38n">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="IIvmWM"></path>
                                </svg>
                            </div>
                        </section>
                        <section class="_167Mu3 _2hbLCH">
                            <div class="_213eRC _2ssEMF">
                                <div class="_2gmUFU _3V8rao">Availability</div><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="ttx38n">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="IIvmWM"></path>
                                </svg>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
        <div class="_1YokD2 _3Mn1Gg" style="flex-grow: 1; overflow: auto;">
            <div class="_1YokD2 _2GoDe3 col-12-12" style="background-color: rgb(255, 255, 255); align-items: flex-end;">
                <div class="_1AtVbE" style="flex-grow: 1; overflow: auto;">
                    <div class="W_R1IA">
                        <div class="_1MR4o5">
                            <div class="_3GIHBu"><a href="/" class="_2whKao">Home</a><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="_39X-Og">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="DpXnhQ"></path>
                                </svg></div>
                            <div class="_3GIHBu"><a class="_2whKao" href="/computers/pr?sid=6bo&amp;marketplace=FLIPKART">Computers</a><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="_39X-Og">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="DpXnhQ"></path>
                                </svg></div>
                            <div class="_3GIHBu"><a class="_2whKao" href="/computers/computer-components/pr?sid=6bo,g0i&amp;marketplace=FLIPKART">Computer Components</a><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="_39X-Og">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="DpXnhQ"></path>
                                </svg></div>
                            <div class="_3GIHBu"><a class="_2whKao" href="/computers/computer-components/monitors/pr?sid=6bo,g0i,9no&amp;marketplace=FLIPKART">Monitors</a><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="_39X-Og">
                                    <path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#fff" class="DpXnhQ"></path>
                                </svg></div>
                        </div>
                        <div class="col gu12 _1c0opE uJ3Xih">
                            <div class="_1D76KH"><a href="https://www.flipkart.com/monitors/msi~brand/pr?sid=6bo,g0i,9no">MSI Monitors</a> ,<a href="https://www.flipkart.com/monitors/hp~brand/pr?sid=6bo,g0i,9no">HP Monitors</a> ,<a href="https://www.flipkart.com/monitors/philips~brand/pr?sid=6bo,g0i,9no">Philips Monitors</a> ,<a href="https://www.flipkart.com/monitors/lg~brand/pr?sid=6bo,g0i,9no">lg Monitors</a> ,<a href="https://www.flipkart.com/monitors/dell~brand/pr?sid=6bo,g0i,9no">DELL Monitors</a> ,<a href="https://www.flipkart.com/monitors/lg~brand/pr?sid=6bo,g0i,9no">LG Monitors</a> ,<a href="https://www.flipkart.com/monitors/asus~brand/pr?sid=6bo,g0i,9no">Asus Monitors</a> ,<a href="https://www.flipkart.com/monitors/zebronics~brand/pr?sid=6bo,g0i,9no">ZEBRONICS Monitors</a> ,<a href="https://www.flipkart.com/monitors/lenovo~brand/pr?sid=6bo,g0i,9no">Lenovo Monitors</a> ,<a href="https://www.flipkart.com/monitors/enter~brand/pr?sid=6bo,g0i,9no">Enter Monitors</a><br></div>
                        </div>
                        <h1 class="_10Ermr">Curved Monitors</h1><span class="_2tDckM">(Showing 1 – 15 products of 15 products)</span>
                        <div class="_5THWM1"><span class="_2i7N3j">Sort By</span>
                            <div class="_10UF8M _3LsR0e">Popularity</div>
                            <div class="_10UF8M">Price -- Low to High</div>
                            <div class="_10UF8M">Price -- High to Low</div>
                            <div class="_10UF8M">Newest First</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="_1AtVbE col-12-12">
                <div class="_13oc-S">
                    <div data-id="MONGHYDYGZVXTBS9" style="width: 100%;">
                        <div class="_2kHMtA" data-tkid="1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONGHYDYGZVXTBS9.SEARCH"><a class="_1fQZEK" target="_blank" rel="noopener noreferrer" href="/acer-23-6-inch-curved-full-hd-va-panel-vesa-mount-support-1500r-curvature-hdmi-1-4-integrated-speakers-gaming-monitor-ed240q/p/itm30fe5e5a30da7?pid=MONGHYDYGZVXTBS9&amp;lid=LSTMONGHYDYGZVXTBS9BLPT6M&amp;marketplace=FLIPKART&amp;store=6bo%2Fg0i%2F9no&amp;spotlightTagId=FkPickId_6bo%2Fg0i%2F9no&amp;srno=b_1_1&amp;otracker=hp_omu_Top%2BOffers_3_4.dealCard.OMU_LNGPL5W28IL5_3&amp;otracker1=hp_omu_PINNED_neo%2Fmerchandising_Top%2BOffers_NA_dealCard_cc_3_NA_view-all_3&amp;fm=neo%2Fmerchandising&amp;iid=1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONGHYDYGZVXTBS9.SEARCH&amp;ppt=browse&amp;ppn=browse&amp;ssid=2njax88o1c0000001687613497461">
                                <div>
                                    <div class="_220jKJ JyiPCp" style="background: rgb(53, 54, 56);">Flipkart's Choice</div>
                                </div>
                                <div class="MIXNux">
                                    <div class="_2QcLo-">
                                        <div>
                                            <div class="CXW8mj" style="height: 200px; width: 200px;"><img loading="eager" class="_396cs4" alt="Acer 23.6 inch Curved Full HD VA Panel with VESA Mount Support, 1500R Curvature, HDMI 1.4, Integrated ..." src="https://rukminim1.flixcart.com/image/312/312/xif0q/monitor/r/5/v/-original-imaggd38vfwc6h7v.jpeg?q=70"></div>
                                        </div>
                                    </div>
                                    <div class="_3wLduG"></div>
                                    <div class="_2hVSre _3nq8ih">
                                        <div class="_36FSn5"><svg xmlns="http://www.w3.org/2000/svg" class="_1l0elc" width="16" height="16" viewBox="0 0 20 16">
                                                <path d="M8.695 16.682C4.06 12.382 1 9.536 1 6.065 1 3.219 3.178 1 5.95 1c1.566 0 3.069.746 4.05 1.915C10.981 1.745 12.484 1 14.05 1 16.822 1 19 3.22 19 6.065c0 3.471-3.06 6.316-7.695 10.617L10 17.897l-1.305-1.215z" fill="#2874F0" class="eX72wL" stroke="#FFF" fill-rule="evenodd" opacity=".9"></path>
                                            </svg></div>
                                    </div>
                                </div>
                                <div class="_3pLy-c row">
                                    <div class="col col-7-12">
                                        <div class="_4rR01T">Acer 23.6 inch Curved Full HD VA Panel with VESA Mount Support, 1500R Curvature, HDMI 1.4, Integrated ...</div>
                                        <div class="gUuXy-"><span id="productRating_LSTMONGHYDYGZVXTBS9BLPT6M_MONGHYDYGZVXTBS9_" class="_1lRcqv">
                                                <div class="_3LWZlK">4.4<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                            </span><span class="_2_R_DZ"><span><span>895 Ratings&nbsp;</span><span class="_13vcmD">&amp;</span><span>&nbsp;136 Reviews</span></span></span></div>
                                        <div class="fMghEO">
                                            <ul class="_1xgFaf">
                                                <li class="rgWa7D">Panel Type: VA Panel</li>
                                                <li class="rgWa7D">Screen Resolution Type: Full HD</li>
                                                <li class="rgWa7D">Brightness: 250 nits</li>
                                                <li class="rgWa7D">Response Time: 1 ms | Refresh Rate: 75 Hz</li>
                                                <li class="rgWa7D">3 Years Warranty</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col col-5-12 nlI3QM">
                                        <div class="_3tbKJL">
                                            <div class="_25b18c">
                                                <div class="_30jeq3 _1_WHN1">₹8,299</div>
                                                <div class="_3I9_wc _27UcVY">₹9,999</div>
                                                <div class="_3Ay6Sb"><span>17% off</span></div>
                                            </div>
                                            <div class="_3tcB5a p8ucoS">
                                                <div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-weight: 400;">Free delivery by</div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-style: normal; font-weight: 700;"> 27th Jun</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="_13J9qT"><img height="21" src="//static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png"></div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;">Upto </div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 700;">₹220</div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;"> Off on Exchange</div>
                                            </div>
                                        </div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(38, 165, 65); font-size: 14px; font-weight: 700;">Bank Offer</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a></div>
                    </div>
                </div>
            </div>
            <div class="_1AtVbE col-12-12">
                <div class="_13oc-S">
                    <div data-id="MONGYJU8UGHXZ7FZ" style="width: 100%;">
                        <div class="_2kHMtA" data-tkid="1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONGYJU8UGHXZ7FZ.SEARCH"><a class="_1fQZEK" target="_blank" rel="noopener noreferrer" href="/lg-29-inch-wfhd-led-backlit-ips-panel-hdr-10-black-stabilizer-dynamic-action-sync-dual-controller-onscreen-control-immersive-ultrawide-monitor-29wl500/p/itm9e5588cf9adc8?pid=MONGYJU8UGHXZ7FZ&amp;lid=LSTMONGYJU8UGHXZ7FZYJH4YZ&amp;marketplace=FLIPKART&amp;store=6bo%2Fg0i%2F9no&amp;srno=b_1_2&amp;otracker=hp_omu_Top%2BOffers_3_4.dealCard.OMU_LNGPL5W28IL5_3&amp;otracker1=hp_omu_PINNED_neo%2Fmerchandising_Top%2BOffers_NA_dealCard_cc_3_NA_view-all_3&amp;fm=neo%2Fmerchandising&amp;iid=1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONGYJU8UGHXZ7FZ.SEARCH&amp;ppt=hp&amp;ppn=homepage&amp;ssid=2njax88o1c0000001687613497461">
                                <div class="MIXNux">
                                    <div class="_2QcLo-">
                                        <div>
                                            <div class="CXW8mj" style="height: 200px; width: 200px;"><img loading="eager" class="_396cs4" alt="LG 29 inch WFHD LED Backlit IPS Panel with HDR 10, Black Stabilizer, Dynamic Action Sync, Dual Control..." src="https://rukminim1.flixcart.com/image/312/312/krjjde80/monitor/x/0/b/29wl500-29-29wl500-lg-original-imag5bahfustv6cr.jpeg?q=70"></div>
                                        </div>
                                    </div>
                                    <div class="_3wLduG"></div>
                                    <div class="_2hVSre _3nq8ih">
                                        <div class="_36FSn5"><svg xmlns="http://www.w3.org/2000/svg" class="_1l0elc" width="16" height="16" viewBox="0 0 20 16">
                                                <path d="M8.695 16.682C4.06 12.382 1 9.536 1 6.065 1 3.219 3.178 1 5.95 1c1.566 0 3.069.746 4.05 1.915C10.981 1.745 12.484 1 14.05 1 16.822 1 19 3.22 19 6.065c0 3.471-3.06 6.316-7.695 10.617L10 17.897l-1.305-1.215z" fill="#2874F0" class="eX72wL" stroke="#FFF" fill-rule="evenodd" opacity=".9"></path>
                                            </svg></div>
                                    </div>
                                </div>
                                <div class="_3pLy-c row">
                                    <div class="col col-7-12">
                                        <div class="_4rR01T">LG 29 inch WFHD LED Backlit IPS Panel with HDR 10, Black Stabilizer, Dynamic Action Sync, Dual Control...</div>
                                        <div class="gUuXy-"><span id="productRating_LSTMONGYJU8UGHXZ7FZYJH4YZ_MONGYJU8UGHXZ7FZ_" class="_1lRcqv">
                                                <div class="_3LWZlK">4.5<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                            </span><span class="_2_R_DZ"><span><span>205 Ratings&nbsp;</span><span class="_13vcmD">&amp;</span><span>&nbsp;19 Reviews</span></span></span></div>
                                        <div class="fMghEO">
                                            <ul class="_1xgFaf">
                                                <li class="rgWa7D">Panel Type: IPS Panel</li>
                                                <li class="rgWa7D">Screen Resolution Type: WFHD</li>
                                                <li class="rgWa7D">Brightness: 250 nits</li>
                                                <li class="rgWa7D">Response Time: 5 ms | Refresh Rate: 75 Hz</li>
                                                <li class="rgWa7D">HDMI Ports - 2</li>
                                                <li class="rgWa7D">3 Years Warranty Provided by the Manufacturer from Fate of Purchase</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col col-5-12 nlI3QM">
                                        <div class="_3tbKJL">
                                            <div class="_25b18c">
                                                <div class="_30jeq3 _1_WHN1">₹17,350</div>
                                                <div class="_3I9_wc _27UcVY">₹23,000</div>
                                                <div class="_3Ay6Sb"><span>24% off</span></div>
                                            </div>
                                            <div class="_3tcB5a p8ucoS">
                                                <div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-weight: 400;">Free delivery</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="_13J9qT"><img height="21" src="//static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png"></div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(199, 0, 85); font-size: 12px; font-weight: 700;">Only 4 left</div>
                                            </div>
                                        </div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(38, 165, 65); font-size: 14px; font-weight: 700;">Bank Offer</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a></div>
                    </div>
                </div>
            </div>
            <div class="_1AtVbE col-12-12">
                <div class="_13oc-S">
                    <div data-id="MONEZU4Z8BYBV2GZ" style="width: 100%;">
                        <div class="_2kHMtA" data-tkid="1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONEZU4Z8BYBV2GZ.SEARCH"><a class="_1fQZEK" target="_blank" rel="noopener noreferrer" href="/samsung-23-8-inch-curved-full-hd-led-backlit-va-panel-1800r-hdmi-audio-ports-flicker-free-slim-design-monitor-lc24f390fhwxxl-ls24c360eawxxl/p/itm1590d895ebc96?pid=MONEZU4Z8BYBV2GZ&amp;lid=LSTMONEZU4Z8BYBV2GZGGVTPD&amp;marketplace=FLIPKART&amp;store=6bo%2Fg0i%2F9no&amp;srno=b_1_3&amp;otracker=hp_omu_Top%2BOffers_3_4.dealCard.OMU_LNGPL5W28IL5_3&amp;otracker1=hp_omu_PINNED_neo%2Fmerchandising_Top%2BOffers_NA_dealCard_cc_3_NA_view-all_3&amp;fm=neo%2Fmerchandising&amp;iid=1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONEZU4Z8BYBV2GZ.SEARCH&amp;ppt=hp&amp;ppn=homepage&amp;ssid=2njax88o1c0000001687613497461">
                                <div class="MIXNux">
                                    <div class="_2QcLo-">
                                        <div>
                                            <div class="CXW8mj" style="height: 200px; width: 200px;"><img loading="eager" class="_396cs4" alt="SAMSUNG 23.8 inch Curved Full HD LED Backlit VA Panel with 1800R, HDMI, Audio Ports, HDMI, Flicker Fre..." src="https://rukminim1.flixcart.com/image/312/312/xif0q/monitor/5/t/s/-original-imagppc6tyfe3jxf.jpeg?q=70"></div>
                                        </div>
                                    </div>
                                    <div class="_3wLduG"></div>
                                    <div class="_2hVSre _3nq8ih">
                                        <div class="_36FSn5"><svg xmlns="http://www.w3.org/2000/svg" class="_1l0elc" width="16" height="16" viewBox="0 0 20 16">
                                                <path d="M8.695 16.682C4.06 12.382 1 9.536 1 6.065 1 3.219 3.178 1 5.95 1c1.566 0 3.069.746 4.05 1.915C10.981 1.745 12.484 1 14.05 1 16.822 1 19 3.22 19 6.065c0 3.471-3.06 6.316-7.695 10.617L10 17.897l-1.305-1.215z" fill="#2874F0" class="eX72wL" stroke="#FFF" fill-rule="evenodd" opacity=".9"></path>
                                            </svg></div>
                                    </div>
                                </div>
                                <div class="_3pLy-c row">
                                    <div class="col col-7-12">
                                        <div class="_4rR01T">SAMSUNG 23.8 inch Curved Full HD LED Backlit VA Panel with 1800R, HDMI, Audio Ports, HDMI, Flicker Fre...</div>
                                        <div class="gUuXy-"><span id="productRating_LSTMONEZU4Z8BYBV2GZGGVTPD_MONEZU4Z8BYBV2GZ_" class="_1lRcqv">
                                                <div class="_3LWZlK">4.5<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                            </span><span class="_2_R_DZ"><span><span>3,289 Ratings&nbsp;</span><span class="_13vcmD">&amp;</span><span>&nbsp;545 Reviews</span></span></span></div>
                                        <div class="fMghEO">
                                            <ul class="_1xgFaf">
                                                <li class="rgWa7D">Panel Type: VA Panel</li>
                                                <li class="rgWa7D">Screen Resolution Type: Full HD</li>
                                                <li class="rgWa7D">VGA Support | HDMI</li>
                                                <li class="rgWa7D">Brightness: 250 nits</li>
                                                <li class="rgWa7D">Response Time: 4 ms | Refresh Rate: 60 Hz</li>
                                                <li class="rgWa7D">HDMI Ports - 1</li>
                                                <li class="rgWa7D">3 Years Warranty on Product From Manufacturer</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col col-5-12 nlI3QM">
                                        <div class="_3tbKJL">
                                            <div class="_25b18c">
                                                <div class="_30jeq3 _1_WHN1">₹9,499</div>
                                                <div class="_3I9_wc _27UcVY">₹16,500</div>
                                                <div class="_3Ay6Sb"><span>42% off</span></div>
                                            </div>
                                            <div class="_3tcB5a p8ucoS">
                                                <div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-weight: 400;">Free delivery by</div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-style: normal; font-weight: 700;"> 27th Jun</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="_13J9qT"><img height="21" src="//static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png"></div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(38, 165, 65); font-size: 12px; font-weight: 700;">Daily Saver</div>
                                            </div>
                                        </div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;">Upto </div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 700;">₹220</div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;"> Off on Exchange</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a></div>
                    </div>
                </div>
            </div>
            <div class="_1AtVbE col-12-12">
                <div class="_13oc-S">
                    <div data-id="MONFZZYJDAZ75SNV" style="width: 100%;">
                        <div class="_2kHMtA" data-tkid="1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONFZZYJDAZ75SNV.SEARCH"><a class="_1fQZEK" target="_blank" rel="noopener noreferrer" href="/msi-optix-23-6-inch-curved-full-hd-va-panel-gaming-monitor-optix-g24c4/p/itmeb6e260127c3f?pid=MONFZZYJDAZ75SNV&amp;lid=LSTMONFZZYJDAZ75SNVOQNCEP&amp;marketplace=FLIPKART&amp;store=6bo%2Fg0i%2F9no&amp;srno=b_1_4&amp;otracker=hp_omu_Top%2BOffers_3_4.dealCard.OMU_LNGPL5W28IL5_3&amp;otracker1=hp_omu_PINNED_neo%2Fmerchandising_Top%2BOffers_NA_dealCard_cc_3_NA_view-all_3&amp;fm=neo%2Fmerchandising&amp;iid=1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONFZZYJDAZ75SNV.SEARCH&amp;ppt=hp&amp;ppn=homepage&amp;ssid=2njax88o1c0000001687613497461">
                                <div class="MIXNux">
                                    <div class="_2QcLo-">
                                        <div>
                                            <div class="CXW8mj" style="height: 200px; width: 200px;"><img loading="eager" class="_396cs4" alt="MSI Optix 23.6 inch Curved Full HD VA Panel Gaming Monitor (Optix G24C4)" src="https://rukminim1.flixcart.com/image/312/312/ktlu9ow0/monitor/h/q/x/optix-g24c4-full-hd-optix-g24c4-msi-original-imag6wthhjgv7gf8.jpeg?q=70"></div>
                                        </div>
                                    </div>
                                    <div class="_3wLduG"></div>
                                    <div class="_2hVSre _3nq8ih">
                                        <div class="_36FSn5"><svg xmlns="http://www.w3.org/2000/svg" class="_1l0elc" width="16" height="16" viewBox="0 0 20 16">
                                                <path d="M8.695 16.682C4.06 12.382 1 9.536 1 6.065 1 3.219 3.178 1 5.95 1c1.566 0 3.069.746 4.05 1.915C10.981 1.745 12.484 1 14.05 1 16.822 1 19 3.22 19 6.065c0 3.471-3.06 6.316-7.695 10.617L10 17.897l-1.305-1.215z" fill="#2874F0" class="eX72wL" stroke="#FFF" fill-rule="evenodd" opacity=".9"></path>
                                            </svg></div>
                                    </div>
                                </div>
                                <div class="_3pLy-c row">
                                    <div class="col col-7-12">
                                        <div class="_4rR01T">MSI Optix 23.6 inch Curved Full HD VA Panel Gaming Monitor (Optix G24C4)</div>
                                        <div class="gUuXy-"><span id="productRating_LSTMONFZZYJDAZ75SNVOQNCEP_MONFZZYJDAZ75SNV_" class="_1lRcqv">
                                                <div class="_3LWZlK">4.7<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                            </span><span class="_2_R_DZ"><span><span>389 Ratings&nbsp;</span><span class="_13vcmD">&amp;</span><span>&nbsp;51 Reviews</span></span></span></div>
                                        <div class="fMghEO">
                                            <ul class="_1xgFaf">
                                                <li class="rgWa7D">Panel Type: VA Panel</li>
                                                <li class="rgWa7D">Screen Resolution Type: Full HD</li>
                                                <li class="rgWa7D">Brightness: 250 nits</li>
                                                <li class="rgWa7D">Response Time: 1 ms | Refresh Rate: 144 Hz</li>
                                                <li class="rgWa7D">3 Year Manufucature warranty</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col col-5-12 nlI3QM">
                                        <div class="_3tbKJL">
                                            <div class="_25b18c">
                                                <div class="_30jeq3 _1_WHN1">₹15,399</div>
                                                <div class="_3I9_wc _27UcVY">₹24,000</div>
                                                <div class="_3Ay6Sb"><span>35% off</span></div>
                                            </div>
                                            <div class="_3tcB5a p8ucoS">
                                                <div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-weight: 400;">Free delivery by</div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-style: normal; font-weight: 700;"> 28th Jun</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="_13J9qT"><img height="21" src="//static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png"></div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;">Upto </div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 700;">₹220</div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;"> Off on Exchange</div>
                                            </div>
                                        </div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(38, 165, 65); font-size: 14px; font-weight: 700;">Bank Offer</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a></div>
                    </div>
                </div>
            </div>
            <div class="_1AtVbE col-12-12">
                <div class="_13oc-S">
                    <div data-id="MONFZBH2YDXDNRUD" style="width: 100%;">
                        <div class="_2kHMtA" data-tkid="1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONFZBH2YDXDNRUD.SEARCH"><a class="_1fQZEK" target="_blank" rel="noopener noreferrer" href="/samsung-27-inch-curved-full-hd-led-backlit-va-panel-gaming-monitor-lc27g75tqswxxl/p/itm3adff8142f2b3?pid=MONFZBH2YDXDNRUD&amp;lid=LSTMONFZBH2YDXDNRUDMX67JC&amp;marketplace=FLIPKART&amp;store=6bo%2Fg0i%2F9no&amp;srno=b_1_5&amp;otracker=hp_omu_Top%2BOffers_3_4.dealCard.OMU_LNGPL5W28IL5_3&amp;otracker1=hp_omu_PINNED_neo%2Fmerchandising_Top%2BOffers_NA_dealCard_cc_3_NA_view-all_3&amp;fm=neo%2Fmerchandising&amp;iid=1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONFZBH2YDXDNRUD.SEARCH&amp;ppt=hp&amp;ppn=homepage&amp;ssid=2njax88o1c0000001687613497461">
                                <div class="MIXNux">
                                    <div class="_2QcLo-">
                                        <div>
                                            <div class="CXW8mj" style="height: 200px; width: 200px;"><img loading="eager" class="_396cs4" alt="SAMSUNG 27 inch Curved Full HD LED Backlit VA Panel Gaming Monitor (LC27G75TQSWXXL)" src="https://rukminim1.flixcart.com/image/312/312/kkec4280/monitor/u/g/c/lc27g75tqswxxl-lc27g75tqswxxl-samsung-original-imafzqvfcahbarfg.jpeg?q=70"></div>
                                        </div>
                                    </div>
                                    <div class="_3wLduG"></div>
                                    <div class="_2hVSre _3nq8ih">
                                        <div class="_36FSn5"><svg xmlns="http://www.w3.org/2000/svg" class="_1l0elc" width="16" height="16" viewBox="0 0 20 16">
                                                <path d="M8.695 16.682C4.06 12.382 1 9.536 1 6.065 1 3.219 3.178 1 5.95 1c1.566 0 3.069.746 4.05 1.915C10.981 1.745 12.484 1 14.05 1 16.822 1 19 3.22 19 6.065c0 3.471-3.06 6.316-7.695 10.617L10 17.897l-1.305-1.215z" fill="#2874F0" class="eX72wL" stroke="#FFF" fill-rule="evenodd" opacity=".9"></path>
                                            </svg></div>
                                    </div>
                                </div>
                                <div class="_3pLy-c row">
                                    <div class="col col-7-12">
                                        <div class="_4rR01T">SAMSUNG 27 inch Curved Full HD LED Backlit VA Panel Gaming Monitor (LC27G75TQSWXXL)</div>
                                        <div class="gUuXy-"><span id="productRating_LSTMONFZBH2YDXDNRUDMX67JC_MONFZBH2YDXDNRUD_" class="_1lRcqv">
                                                <div class="_3LWZlK">4.5<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                            </span><span class="_2_R_DZ"><span><span>17 Ratings&nbsp;</span><span class="_13vcmD">&amp;</span><span>&nbsp;6 Reviews</span></span></span></div>
                                        <div class="fMghEO">
                                            <ul class="_1xgFaf">
                                                <li class="rgWa7D">Panel Type: VA Panel</li>
                                                <li class="rgWa7D">Screen Resolution Type: Full HD</li>
                                                <li class="rgWa7D">Brightness: 600 Units</li>
                                                <li class="rgWa7D">Response Time: 1 ms | Refresh Rate: 240 Hz</li>
                                                <li class="rgWa7D">HDMI Ports - 1</li>
                                                <li class="rgWa7D">1 Year Warranty on Product</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col col-5-12 nlI3QM">
                                        <div class="_3tbKJL">
                                            <div class="_25b18c">
                                                <div class="_30jeq3 _1_WHN1">₹42,043</div>
                                                <div class="_3I9_wc _27UcVY">₹66,000</div>
                                                <div class="_3Ay6Sb"><span>36% off</span></div>
                                            </div>
                                            <div class="_3tcB5a p8ucoS">
                                                <div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-weight: 400;">Free delivery by</div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-style: normal; font-weight: 700;"> 27th Jun</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="_13J9qT"><img height="21" src="//static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png"></div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;">Upto </div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 700;">₹220</div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;"> Off on Exchange</div>
                                            </div>
                                        </div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(38, 165, 65); font-size: 14px; font-weight: 700;">Bank Offer</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a></div>
                    </div>
                </div>
            </div>
            <div class="_1AtVbE col-12-12">
                <div class="_13oc-S">
                    <div data-id="MONFY8PGR8XKKCKG" style="width: 100%;">
                        <div class="_2kHMtA" data-tkid="1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONFY8PGR8XKKCKG.SEARCH"><a class="_1fQZEK" target="_blank" rel="noopener noreferrer" href="/hp-23-6-inch-curved-full-hd-led-backlit-va-panel-gaming-monitor-x24c/p/itmee50fb3292b31?pid=MONFY8PGR8XKKCKG&amp;lid=LSTMONFY8PGR8XKKCKG1UUSA4&amp;marketplace=FLIPKART&amp;store=6bo%2Fg0i%2F9no&amp;srno=b_1_6&amp;otracker=hp_omu_Top%2BOffers_3_4.dealCard.OMU_LNGPL5W28IL5_3&amp;otracker1=hp_omu_PINNED_neo%2Fmerchandising_Top%2BOffers_NA_dealCard_cc_3_NA_view-all_3&amp;fm=neo%2Fmerchandising&amp;iid=1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONFY8PGR8XKKCKG.SEARCH&amp;ppt=hp&amp;ppn=homepage&amp;ssid=2njax88o1c0000001687613497461">
                                <div class="MIXNux">
                                    <div class="_2QcLo-">
                                        <div>
                                            <div class="CXW8mj" style="height: 200px; width: 200px;"><img loading="eager" class="_396cs4" alt="HP 23.6 inch Curved Full HD LED Backlit VA Panel Gaming Monitor (X24c)" src="https://rukminim1.flixcart.com/image/312/312/kirr24w0/monitor/c/k/g/x24c-13q95aa-hp-original-imafyhbr5fpnyzqs.jpeg?q=70"></div>
                                        </div>
                                    </div>
                                    <div class="_3wLduG"></div>
                                    <div class="_2hVSre _3nq8ih">
                                        <div class="_36FSn5"><svg xmlns="http://www.w3.org/2000/svg" class="_1l0elc" width="16" height="16" viewBox="0 0 20 16">
                                                <path d="M8.695 16.682C4.06 12.382 1 9.536 1 6.065 1 3.219 3.178 1 5.95 1c1.566 0 3.069.746 4.05 1.915C10.981 1.745 12.484 1 14.05 1 16.822 1 19 3.22 19 6.065c0 3.471-3.06 6.316-7.695 10.617L10 17.897l-1.305-1.215z" fill="#2874F0" class="eX72wL" stroke="#FFF" fill-rule="evenodd" opacity=".9"></path>
                                            </svg></div>
                                    </div>
                                </div>
                                <div class="_3pLy-c row">
                                    <div class="col col-7-12">
                                        <div class="_4rR01T">HP 23.6 inch Curved Full HD LED Backlit VA Panel Gaming Monitor (X24c)</div>
                                        <div class="gUuXy-"><span id="productRating_LSTMONFY8PGR8XKKCKG1UUSA4_MONFY8PGR8XKKCKG_" class="_1lRcqv">
                                                <div class="_3LWZlK">4.5<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                            </span><span class="_2_R_DZ"><span><span>56 Ratings&nbsp;</span><span class="_13vcmD">&amp;</span><span>&nbsp;7 Reviews</span></span></span></div>
                                        <div class="fMghEO">
                                            <ul class="_1xgFaf">
                                                <li class="rgWa7D">Panel Type: VA Panel</li>
                                                <li class="rgWa7D">Screen Resolution Type: Full HD</li>
                                                <li class="rgWa7D">Brightness: 300 Nits</li>
                                                <li class="rgWa7D">Response Time: 4 ms | Refresh Rate: 144 Hz</li>
                                                <li class="rgWa7D">HDMI Ports - 1</li>
                                                <li class="rgWa7D">3 Years Warranty Provided by the Manufacturer from Date of Purchase</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col col-5-12 nlI3QM">
                                        <div class="_3tbKJL">
                                            <div class="_25b18c">
                                                <div class="_30jeq3 _1_WHN1">₹18,172</div>
                                                <div class="_3I9_wc _27UcVY">₹18,480</div>
                                                <div class="_3Ay6Sb"><span>1% off</span></div>
                                            </div>
                                            <div class="_3tcB5a p8ucoS">
                                                <div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-weight: 400;">Free delivery by</div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-style: normal; font-weight: 700;"> 27th Jun</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="_13J9qT"><img height="21" src="//static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png"></div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;">Upto </div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 700;">₹220</div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;"> Off on Exchange</div>
                                            </div>
                                        </div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(38, 165, 65); font-size: 14px; font-weight: 700;">Bank Offer</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a></div>
                    </div>
                </div>
            </div>
            <div class="_1AtVbE col-12-12">
                <div class="_13oc-S">
                    <div data-id="MONG3GKKR4U2KB2N" style="width: 100%;">
                        <div class="_2kHMtA" data-tkid="1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONG3GKKR4U2KB2N.SEARCH"><a class="_1fQZEK" target="_blank" rel="noopener noreferrer" href="/msi-optix-23-8-inch-curved-full-hd-va-panel-gaming-monitor-optix-g24c6p/p/itm78142de20ec6c?pid=MONG3GKKR4U2KB2N&amp;lid=LSTMONG3GKKR4U2KB2NEPWY2U&amp;marketplace=FLIPKART&amp;store=6bo%2Fg0i%2F9no&amp;srno=b_1_7&amp;otracker=hp_omu_Top%2BOffers_3_4.dealCard.OMU_LNGPL5W28IL5_3&amp;otracker1=hp_omu_PINNED_neo%2Fmerchandising_Top%2BOffers_NA_dealCard_cc_3_NA_view-all_3&amp;fm=neo%2Fmerchandising&amp;iid=1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONG3GKKR4U2KB2N.SEARCH&amp;ppt=hp&amp;ppn=homepage&amp;ssid=2njax88o1c0000001687613497461">
                                <div class="MIXNux">
                                    <div class="_2QcLo-">
                                        <div>
                                            <div class="CXW8mj" style="height: 200px; width: 200px;"><img loading="eager" class="_396cs4" alt="MSI Optix 23.8 inch Curved Full HD VA Panel Gaming Monitor (Optix G24C6P)" src="https://rukminim1.flixcart.com/image/312/312/ktlu9ow0/monitor/a/j/2/optix-g24c6p-full-hd-optix-g24c6p-msi-original-imag6wtkeynzx3gg.jpeg?q=70"></div>
                                        </div>
                                    </div>
                                    <div class="_3wLduG"></div>
                                    <div class="_2hVSre _3nq8ih">
                                        <div class="_36FSn5"><svg xmlns="http://www.w3.org/2000/svg" class="_1l0elc" width="16" height="16" viewBox="0 0 20 16">
                                                <path d="M8.695 16.682C4.06 12.382 1 9.536 1 6.065 1 3.219 3.178 1 5.95 1c1.566 0 3.069.746 4.05 1.915C10.981 1.745 12.484 1 14.05 1 16.822 1 19 3.22 19 6.065c0 3.471-3.06 6.316-7.695 10.617L10 17.897l-1.305-1.215z" fill="#2874F0" class="eX72wL" stroke="#FFF" fill-rule="evenodd" opacity=".9"></path>
                                            </svg></div>
                                    </div>
                                </div>
                                <div class="_3pLy-c row">
                                    <div class="col col-7-12">
                                        <div class="_4rR01T">MSI Optix 23.8 inch Curved Full HD VA Panel Gaming Monitor (Optix G24C6P)</div>
                                        <div class="gUuXy-"><span id="productRating_LSTMONG3GKKR4U2KB2NEPWY2U_MONG3GKKR4U2KB2N_" class="_1lRcqv">
                                                <div class="_3LWZlK">4.5<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                            </span><span class="_2_R_DZ"><span><span>34 Ratings&nbsp;</span><span class="_13vcmD">&amp;</span><span>&nbsp;4 Reviews</span></span></span></div>
                                        <div class="fMghEO">
                                            <ul class="_1xgFaf">
                                                <li class="rgWa7D">Panel Type: VA Panel</li>
                                                <li class="rgWa7D">Screen Resolution Type: Full HD</li>
                                                <li class="rgWa7D">Brightness: 250 nits</li>
                                                <li class="rgWa7D">Response Time: 1 ms | Refresh Rate: 144 Hz</li>
                                                <li class="rgWa7D">3 Year Manufucature warranty</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col col-5-12 nlI3QM">
                                        <div class="_3tbKJL">
                                            <div class="_25b18c">
                                                <div class="_30jeq3 _1_WHN1">₹16,499</div>
                                                <div class="_3I9_wc _27UcVY">₹26,250</div>
                                                <div class="_3Ay6Sb"><span>37% off</span></div>
                                            </div>
                                            <div class="_3tcB5a p8ucoS">
                                                <div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-weight: 400;">Free delivery by</div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-style: normal; font-weight: 700;"> 28th Jun</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="_13J9qT"><img height="21" src="//static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png"></div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(199, 0, 85); font-size: 12px; font-weight: 700;">Only few left</div>
                                            </div>
                                        </div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;">Upto </div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 700;">₹220</div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;"> Off on Exchange</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a></div>
                    </div>
                </div>
            </div>
            <div class="_1AtVbE col-12-12">
                <div class="_13oc-S">
                    <div data-id="MONFZZYGFX8XYS7G" style="width: 100%;">
                        <div class="_2kHMtA" data-tkid="1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONFZZYGFX8XYS7G.SEARCH"><a class="_1fQZEK" target="_blank" rel="noopener noreferrer" href="/msi-optix-27-inch-curved-full-hd-va-panel-gaming-monitor-optix-g27c4/p/itm62346f3bd253d?pid=MONFZZYGFX8XYS7G&amp;lid=LSTMONFZZYGFX8XYS7GBSA267&amp;marketplace=FLIPKART&amp;store=6bo%2Fg0i%2F9no&amp;spotlightTagId=TrendingId_6bo%2Fg0i%2F9no&amp;srno=b_1_8&amp;otracker=hp_omu_Top%2BOffers_3_4.dealCard.OMU_LNGPL5W28IL5_3&amp;otracker1=hp_omu_PINNED_neo%2Fmerchandising_Top%2BOffers_NA_dealCard_cc_3_NA_view-all_3&amp;fm=neo%2Fmerchandising&amp;iid=1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONFZZYGFX8XYS7G.SEARCH&amp;ppt=hp&amp;ppn=homepage&amp;ssid=2njax88o1c0000001687613497461">
                                <div></div>
                                <div class="MIXNux">
                                    <div class="_2QcLo-">
                                        <div>
                                            <div class="CXW8mj" style="height: 200px; width: 200px;"><img loading="eager" class="_396cs4" alt="MSI Optix 27 inch Curved Full HD VA Panel Gaming Monitor (Optix G27C4)" src="https://rukminim1.flixcart.com/image/312/312/ksru0sw0/monitor/c/f/j/optix-g27c4-full-hd-optix-g27c4-msi-original-imag69gbqqcqq9eb.jpeg?q=70"></div>
                                        </div>
                                    </div>
                                    <div class="_3wLduG"></div>
                                    <div class="_2hVSre _3nq8ih">
                                        <div class="_36FSn5"><svg xmlns="http://www.w3.org/2000/svg" class="_1l0elc" width="16" height="16" viewBox="0 0 20 16">
                                                <path d="M8.695 16.682C4.06 12.382 1 9.536 1 6.065 1 3.219 3.178 1 5.95 1c1.566 0 3.069.746 4.05 1.915C10.981 1.745 12.484 1 14.05 1 16.822 1 19 3.22 19 6.065c0 3.471-3.06 6.316-7.695 10.617L10 17.897l-1.305-1.215z" fill="#2874F0" class="eX72wL" stroke="#FFF" fill-rule="evenodd" opacity=".9"></path>
                                            </svg></div>
                                    </div>
                                </div>
                                <div class="_3pLy-c row">
                                    <div class="col col-7-12">
                                        <div class="_4rR01T">MSI Optix 27 inch Curved Full HD VA Panel Gaming Monitor (Optix G27C4)</div>
                                        <div class="gUuXy-"><span id="productRating_LSTMONFZZYGFX8XYS7GBSA267_MONFZZYGFX8XYS7G_" class="_1lRcqv">
                                                <div class="_3LWZlK">4.2<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                            </span><span class="_2_R_DZ"><span><span>31 Ratings&nbsp;</span><span class="_13vcmD">&amp;</span><span>&nbsp;6 Reviews</span></span></span></div>
                                        <div class="fMghEO">
                                            <ul class="_1xgFaf">
                                                <li class="rgWa7D">Panel Type: VA Panel</li>
                                                <li class="rgWa7D">Screen Resolution Type: Full HD</li>
                                                <li class="rgWa7D">Brightness: 250 nits</li>
                                                <li class="rgWa7D">Response Time: 1 ms | Refresh Rate: 165 Hz</li>
                                                <li class="rgWa7D">3 Year Manufucature warranty</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col col-5-12 nlI3QM">
                                        <div class="_3tbKJL">
                                            <div class="_25b18c">
                                                <div class="_30jeq3 _1_WHN1">₹18,699</div>
                                                <div class="_3I9_wc _27UcVY">₹33,480</div>
                                                <div class="_3Ay6Sb"><span>44% off</span></div>
                                            </div>
                                            <div class="_3tcB5a p8ucoS">
                                                <div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-weight: 400;">Free delivery by</div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-style: normal; font-weight: 700;"> 29th Jun</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="_13J9qT"><img height="21" src="//static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png"></div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(199, 0, 85); font-size: 12px; font-weight: 700;">Only 1 left</div>
                                            </div>
                                        </div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;">Upto </div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 700;">₹220</div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;"> Off on Exchange</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a></div>
                    </div>
                </div>
            </div>
            <div class="_1AtVbE col-12-12">
                <div class="_13oc-S">
                    <div data-id="MONGCZSTVZDVTMDH" style="width: 100%;">
                        <div class="_2kHMtA" data-tkid="1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONGCZSTVZDVTMDH.SEARCH"><a class="_1fQZEK" target="_blank" rel="noopener noreferrer" href="/samsung-24-inch-curved-full-hd-va-panel-game-mode-low-input-lag-eye-saver-mode-flicker-free-immersion-gaming-monitor-lc24rg50fzwxxl/p/itm20a7268d50526?pid=MONGCZSTVZDVTMDH&amp;lid=LSTMONGCZSTVZDVTMDHWNAZQA&amp;marketplace=FLIPKART&amp;store=6bo%2Fg0i%2F9no&amp;srno=b_1_9&amp;otracker=hp_omu_Top%2BOffers_3_4.dealCard.OMU_LNGPL5W28IL5_3&amp;otracker1=hp_omu_PINNED_neo%2Fmerchandising_Top%2BOffers_NA_dealCard_cc_3_NA_view-all_3&amp;fm=neo%2Fmerchandising&amp;iid=1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONGCZSTVZDVTMDH.SEARCH&amp;ppt=hp&amp;ppn=homepage&amp;ssid=2njax88o1c0000001687613497461">
                                <div class="MIXNux">
                                    <div class="_2QcLo-">
                                        <div>
                                            <div class="CXW8mj" style="height: 200px; width: 200px;"><img loading="eager" class="_396cs4" alt="SAMSUNG 24 inch Curved Full HD VA Panel with Game Mode, Low Input Lag, Eye Saver Mode &amp; Flicker Free F..." src="https://rukminim1.flixcart.com/image/312/312/l1b1oy80/monitor/y/n/4/lc24rg50fzwxxl-full-hd-24-lc24rg50fzwxxl-samsung-original-imagcwkrz22hyquf.jpeg?q=70"></div>
                                        </div>
                                    </div>
                                    <div class="_3wLduG"></div>
                                    <div class="_2hVSre _3nq8ih">
                                        <div class="_36FSn5"><svg xmlns="http://www.w3.org/2000/svg" class="_1l0elc" width="16" height="16" viewBox="0 0 20 16">
                                                <path d="M8.695 16.682C4.06 12.382 1 9.536 1 6.065 1 3.219 3.178 1 5.95 1c1.566 0 3.069.746 4.05 1.915C10.981 1.745 12.484 1 14.05 1 16.822 1 19 3.22 19 6.065c0 3.471-3.06 6.316-7.695 10.617L10 17.897l-1.305-1.215z" fill="#2874F0" class="eX72wL" stroke="#FFF" fill-rule="evenodd" opacity=".9"></path>
                                            </svg></div>
                                    </div>
                                </div>
                                <div class="_3pLy-c row">
                                    <div class="col col-7-12">
                                        <div class="_4rR01T">SAMSUNG 24 inch Curved Full HD VA Panel with Game Mode, Low Input Lag, Eye Saver Mode &amp; Flicker Free F...</div>
                                        <div class="gUuXy-"><span id="productRating_LSTMONGCZSTVZDVTMDHWNAZQA_MONGCZSTVZDVTMDH_" class="_1lRcqv">
                                                <div class="_3LWZlK">4.5<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                            </span><span class="_2_R_DZ"><span><span>25 Ratings&nbsp;</span><span class="_13vcmD">&amp;</span><span>&nbsp;4 Reviews</span></span></span></div>
                                        <div class="fMghEO">
                                            <ul class="_1xgFaf">
                                                <li class="rgWa7D">Panel Type: VA Panel</li>
                                                <li class="rgWa7D">Screen Resolution Type: Full HD</li>
                                                <li class="rgWa7D">Brightness: 250 nits</li>
                                                <li class="rgWa7D">Response Time: 4 ms | Refresh Rate: 144 Hz</li>
                                                <li class="rgWa7D">3 Years Warranty</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col col-5-12 nlI3QM">
                                        <div class="_3tbKJL">
                                            <div class="_25b18c">
                                                <div class="_30jeq3 _1_WHN1">₹12,699</div>
                                                <div class="_3I9_wc _27UcVY">₹25,000</div>
                                                <div class="_3Ay6Sb"><span>49% off</span></div>
                                            </div>
                                            <div class="_3tcB5a p8ucoS">
                                                <div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-weight: 400;">Free delivery by</div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-style: normal; font-weight: 700;"> 27th Jun</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="_13J9qT"><img height="21" src="//static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png"></div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(38, 165, 65); font-size: 12px; font-weight: 700;">Hot Deal</div>
                                            </div>
                                        </div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;">Upto </div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 700;">₹220</div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;"> Off on Exchange</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a></div>
                    </div>
                </div>
            </div>
            <div class="_1AtVbE col-12-12">
                <div class="_13oc-S">
                    <div data-id="MONG5ZV3Q2QKSMDD" style="width: 100%;">
                        <div class="_2kHMtA" data-tkid="1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONG5ZV3Q2QKSMDD.SEARCH"><a class="_1fQZEK" target="_blank" rel="noopener noreferrer" href="/acer-hc1-27-inch-curved-full-hd-va-panel-gaming-monitor-27hc1r/p/itm1cdbf40857dff?pid=MONG5ZV3Q2QKSMDD&amp;lid=LSTMONG5ZV3Q2QKSMDDXQ4CMP&amp;marketplace=FLIPKART&amp;store=6bo%2Fg0i%2F9no&amp;srno=b_1_10&amp;otracker=hp_omu_Top%2BOffers_3_4.dealCard.OMU_LNGPL5W28IL5_3&amp;otracker1=hp_omu_PINNED_neo%2Fmerchandising_Top%2BOffers_NA_dealCard_cc_3_NA_view-all_3&amp;fm=neo%2Fmerchandising&amp;iid=1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONG5ZV3Q2QKSMDD.SEARCH&amp;ppt=hp&amp;ppn=homepage&amp;ssid=2njax88o1c0000001687613497461">
                                <div class="MIXNux">
                                    <div class="_2QcLo-">
                                        <div>
                                            <div class="CXW8mj" style="height: 200px; width: 200px;"><img loading="eager" class="_396cs4" alt="Acer HC1 27 inch Curved Full HD VA Panel Gaming Monitor (27HC1R)" src="https://rukminim1.flixcart.com/image/312/312/ksoz53k0/monitor/m/x/q/27hc1r-full-hd-27-um-hw1si-p01-acer-original-imag67pqaf6zbgrz.jpeg?q=70"></div>
                                        </div>
                                    </div>
                                    <div class="_3wLduG"></div>
                                    <div class="_2hVSre _3nq8ih">
                                        <div class="_36FSn5"><svg xmlns="http://www.w3.org/2000/svg" class="_1l0elc" width="16" height="16" viewBox="0 0 20 16">
                                                <path d="M8.695 16.682C4.06 12.382 1 9.536 1 6.065 1 3.219 3.178 1 5.95 1c1.566 0 3.069.746 4.05 1.915C10.981 1.745 12.484 1 14.05 1 16.822 1 19 3.22 19 6.065c0 3.471-3.06 6.316-7.695 10.617L10 17.897l-1.305-1.215z" fill="#2874F0" class="eX72wL" stroke="#FFF" fill-rule="evenodd" opacity=".9"></path>
                                            </svg></div>
                                    </div>
                                </div>
                                <div class="_3pLy-c row">
                                    <div class="col col-7-12">
                                        <div class="_4rR01T">Acer HC1 27 inch Curved Full HD VA Panel Gaming Monitor (27HC1R)</div>
                                        <div class="gUuXy-"><span id="productRating_LSTMONG5ZV3Q2QKSMDDXQ4CMP_MONG5ZV3Q2QKSMDD_" class="_1lRcqv">
                                                <div class="_3LWZlK">4.1<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                            </span><span class="_2_R_DZ"><span><span>58 Ratings&nbsp;</span><span class="_13vcmD">&amp;</span><span>&nbsp;8 Reviews</span></span></span></div>
                                        <div class="fMghEO">
                                            <ul class="_1xgFaf">
                                                <li class="rgWa7D">Panel Type: VA Panel</li>
                                                <li class="rgWa7D">Screen Resolution Type: Full HD</li>
                                                <li class="rgWa7D">Response Time: 4 ms | Refresh Rate: 144 Hz</li>
                                                <li class="rgWa7D">HDMI Ports - 1</li>
                                                <li class="rgWa7D">3 Years Warranty</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col col-5-12 nlI3QM">
                                        <div class="_3tbKJL">
                                            <div class="_25b18c">
                                                <div class="_30jeq3 _1_WHN1">₹18,999</div>
                                                <div class="_3I9_wc _27UcVY">₹43,000</div>
                                                <div class="_3Ay6Sb"><span>55% off</span></div>
                                            </div>
                                            <div class="_3tcB5a p8ucoS">
                                                <div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-weight: 400;">Free delivery by</div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-style: normal; font-weight: 700;"> 29th Jun</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="_13J9qT"><img height="21" src="//static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png"></div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(199, 0, 85); font-size: 12px; font-weight: 700;">Only 1 left</div>
                                            </div>
                                        </div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;">Upto </div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 700;">₹220</div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;"> Off on Exchange</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a></div>
                    </div>
                </div>
            </div>
            <div class="_1AtVbE col-12-12">
                <div class="_13oc-S">
                    <div data-id="MONGC4PWUBVGHZYG" style="width: 100%;">
                        <div class="_2kHMtA" data-tkid="1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONGC4PWUBVGHZYG.SEARCH"><a class="_1fQZEK" target="_blank" rel="noopener noreferrer" href="/msi-27-inch-curved-full-hd-led-backlit-va-panel-frameless-adjustable-stand-anti-flicker-less-blue-light-gaming-monitor-optix-g27c5/p/itm066d7068d3bad?pid=MONGC4PWUBVGHZYG&amp;lid=LSTMONGC4PWUBVGHZYGZ2KT30&amp;marketplace=FLIPKART&amp;store=6bo%2Fg0i%2F9no&amp;srno=b_1_11&amp;otracker=hp_omu_Top%2BOffers_3_4.dealCard.OMU_LNGPL5W28IL5_3&amp;otracker1=hp_omu_PINNED_neo%2Fmerchandising_Top%2BOffers_NA_dealCard_cc_3_NA_view-all_3&amp;fm=neo%2Fmerchandising&amp;iid=1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONGC4PWUBVGHZYG.SEARCH&amp;ppt=hp&amp;ppn=homepage&amp;ssid=2njax88o1c0000001687613497461">
                                <div class="MIXNux">
                                    <div class="_2QcLo-">
                                        <div>
                                            <div class="CXW8mj" style="height: 200px; width: 200px;"><img loading="eager" class="_396cs4" alt="MSI 27 inch Curved Full HD LED Backlit VA Panel Frameless, with Adjustable Stand, Anti-Flicker &amp; Less ..." src="https://rukminim1.flixcart.com/image/312/312/l0cr4i80/monitor/m/y/v/optix-g27c5-full-hd-27-9s6-3ca91t-047-msi-original-imagc63qhkwzymj6.jpeg?q=70"></div>
                                        </div>
                                    </div>
                                    <div class="_3wLduG"></div>
                                    <div class="_2hVSre _3nq8ih">
                                        <div class="_36FSn5"><svg xmlns="http://www.w3.org/2000/svg" class="_1l0elc" width="16" height="16" viewBox="0 0 20 16">
                                                <path d="M8.695 16.682C4.06 12.382 1 9.536 1 6.065 1 3.219 3.178 1 5.95 1c1.566 0 3.069.746 4.05 1.915C10.981 1.745 12.484 1 14.05 1 16.822 1 19 3.22 19 6.065c0 3.471-3.06 6.316-7.695 10.617L10 17.897l-1.305-1.215z" fill="#2874F0" class="eX72wL" stroke="#FFF" fill-rule="evenodd" opacity=".9"></path>
                                            </svg></div>
                                    </div>
                                </div>
                                <div class="_3pLy-c row">
                                    <div class="col col-7-12">
                                        <div class="_4rR01T">MSI 27 inch Curved Full HD LED Backlit VA Panel Frameless, with Adjustable Stand, Anti-Flicker &amp; Less ...</div>
                                        <div class="gUuXy-"><span id="productRating_LSTMONGC4PWUBVGHZYGZ2KT30_MONGC4PWUBVGHZYG_" class="_1lRcqv">
                                                <div class="_3LWZlK">4.1<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                            </span><span class="_2_R_DZ"><span><span>9 Ratings&nbsp;</span><span class="_13vcmD">&amp;</span><span>&nbsp;1 Reviews</span></span></span></div>
                                        <div class="fMghEO">
                                            <ul class="_1xgFaf">
                                                <li class="rgWa7D">Panel Type: VA Panel</li>
                                                <li class="rgWa7D">Screen Resolution Type: Full HD</li>
                                                <li class="rgWa7D">Brightness: 250 nits</li>
                                                <li class="rgWa7D">Response Time: 1 ms | Refresh Rate: 165 Hz</li>
                                                <li class="rgWa7D">HDMI Ports - 2</li>
                                                <li class="rgWa7D">3 Years Limited Warranty</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col col-5-12 nlI3QM">
                                        <div class="_3tbKJL">
                                            <div class="_25b18c">
                                                <div class="_30jeq3 _1_WHN1">₹21,399</div>
                                                <div class="_3I9_wc _27UcVY">₹33,480</div>
                                                <div class="_3Ay6Sb"><span>36% off</span></div>
                                            </div>
                                            <div class="_3tcB5a p8ucoS">
                                                <div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-weight: 400;">Free delivery by</div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-style: normal; font-weight: 700;"> 28th Jun</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;">Upto </div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 700;">₹220</div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;"> Off on Exchange</div>
                                            </div>
                                        </div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(38, 165, 65); font-size: 14px; font-weight: 700;">Bank Offer</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a></div>
                    </div>
                </div>
            </div>
            <div class="_1AtVbE col-12-12">
                <div class="_13oc-S">
                    <div data-id="MONGFG99YTYSH46E" style="width: 100%;">
                        <div class="_2kHMtA" data-tkid="1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONGFG99YTYSH46E.SEARCH"><a class="_1fQZEK" target="_blank" rel="noopener noreferrer" href="/dell-gaming-27-inch-curved-full-hd-led-backlit-va-panel-ultra-slim-bezel-monitor-s2721hgf/p/itm7dbcb03a8afeb?pid=MONGFG99YTYSH46E&amp;lid=LSTMONGFG99YTYSH46EMUPCM0&amp;marketplace=FLIPKART&amp;store=6bo%2Fg0i%2F9no&amp;srno=b_1_12&amp;otracker=hp_omu_Top%2BOffers_3_4.dealCard.OMU_LNGPL5W28IL5_3&amp;otracker1=hp_omu_PINNED_neo%2Fmerchandising_Top%2BOffers_NA_dealCard_cc_3_NA_view-all_3&amp;fm=neo%2Fmerchandising&amp;iid=1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONGFG99YTYSH46E.SEARCH&amp;ppt=hp&amp;ppn=homepage&amp;ssid=2njax88o1c0000001687613497461">
                                <div class="MIXNux">
                                    <div class="_2QcLo-">
                                        <div>
                                            <div class="CXW8mj" style="height: 200px; width: 200px;"><img loading="eager" class="_396cs4" alt="DELL Gaming 27 inch Curved Full HD LED Backlit VA Panel Ultra Slim Bezel Gaming Monitor (S2721HGF)" src="https://rukminim1.flixcart.com/image/312/312/kmxsakw0/monitor/d/n/u/s2721hgf-27-hhgmy-dell-original-imagfq7huhe5j9nw.jpeg?q=70"></div>
                                        </div>
                                    </div>
                                    <div class="_3wLduG"></div>
                                    <div class="_2hVSre _3nq8ih">
                                        <div class="_36FSn5"><svg xmlns="http://www.w3.org/2000/svg" class="_1l0elc" width="16" height="16" viewBox="0 0 20 16">
                                                <path d="M8.695 16.682C4.06 12.382 1 9.536 1 6.065 1 3.219 3.178 1 5.95 1c1.566 0 3.069.746 4.05 1.915C10.981 1.745 12.484 1 14.05 1 16.822 1 19 3.22 19 6.065c0 3.471-3.06 6.316-7.695 10.617L10 17.897l-1.305-1.215z" fill="#2874F0" class="eX72wL" stroke="#FFF" fill-rule="evenodd" opacity=".9"></path>
                                            </svg></div>
                                    </div>
                                </div>
                                <div class="_3pLy-c row">
                                    <div class="col col-7-12">
                                        <div class="_4rR01T">DELL Gaming 27 inch Curved Full HD LED Backlit VA Panel Ultra Slim Bezel Gaming Monitor (S2721HGF)</div>
                                        <div class="gUuXy-"><span id="productRating_LSTMONGFG99YTYSH46EMUPCM0_MONGFG99YTYSH46E_" class="_1lRcqv">
                                                <div class="_3LWZlK">4.8<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                            </span><span class="_2_R_DZ"><span><span>16 Ratings&nbsp;</span><span class="_13vcmD">&amp;</span><span>&nbsp;0 Reviews</span></span></span></div>
                                        <div class="fMghEO">
                                            <ul class="_1xgFaf">
                                                <li class="rgWa7D">Panel Type: VA Panel</li>
                                                <li class="rgWa7D">Screen Resolution Type: Full HD</li>
                                                <li class="rgWa7D">Brightness: 350 nits</li>
                                                <li class="rgWa7D">Response Time: 4 ms | Refresh Rate: 144 Hz</li>
                                                <li class="rgWa7D">HDMI Ports - 2</li>
                                                <li class="rgWa7D">3 Years Domestic Warranty</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col col-5-12 nlI3QM">
                                        <div class="_3tbKJL">
                                            <div class="_25b18c">
                                                <div class="_30jeq3 _1_WHN1">₹24,199</div>
                                                <div class="_3I9_wc _27UcVY">₹33,099</div>
                                                <div class="_3Ay6Sb"><span>26% off</span></div>
                                            </div>
                                            <div class="_3tcB5a p8ucoS">
                                                <div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-weight: 400;">Free delivery by</div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-style: normal; font-weight: 700;"> 28th Jun</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="_13J9qT"><img height="21" src="//static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png"></div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;">Upto </div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 700;">₹220</div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;"> Off on Exchange</div>
                                            </div>
                                        </div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(38, 165, 65); font-size: 14px; font-weight: 700;">Bank Offer</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a></div>
                    </div>
                </div>
            </div>
            <div class="_1AtVbE col-12-12">
                <div class="_13oc-S">
                    <div data-id="MONG5H2QKVBZY6PS" style="width: 100%;">
                        <div class="_2kHMtA" data-tkid="1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONG5H2QKVBZY6PS.SEARCH"><a class="_1fQZEK" target="_blank" rel="noopener noreferrer" href="/hp-27-inch-curved-full-hd-led-backlit-va-panel-gaming-monitor-x27c/p/itmc95e63a9da0af?pid=MONG5H2QKVBZY6PS&amp;lid=LSTMONG5H2QKVBZY6PSF4LUV6&amp;marketplace=FLIPKART&amp;store=6bo%2Fg0i%2F9no&amp;srno=b_1_13&amp;otracker=hp_omu_Top%2BOffers_3_4.dealCard.OMU_LNGPL5W28IL5_3&amp;otracker1=hp_omu_PINNED_neo%2Fmerchandising_Top%2BOffers_NA_dealCard_cc_3_NA_view-all_3&amp;fm=neo%2Fmerchandising&amp;iid=1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONG5H2QKVBZY6PS.SEARCH&amp;ppt=hp&amp;ppn=homepage&amp;ssid=2njax88o1c0000001687613497461">
                                <div class="MIXNux">
                                    <div class="_2QcLo-">
                                        <div>
                                            <div class="CXW8mj" style="height: 200px; width: 200px;"><img loading="eager" class="_396cs4" alt="HP 27 inch Curved Full HD LED Backlit VA Panel Gaming Monitor (X27c)" src="https://rukminim1.flixcart.com/image/312/312/ktaeqvk0/monitor/c/m/y/x27c-full-hd-32g12aa-hp-original-imag6nwxzkhfrpuk.jpeg?q=70"></div>
                                        </div>
                                    </div>
                                    <div class="_3wLduG"></div>
                                    <div class="_2hVSre _3nq8ih">
                                        <div class="_36FSn5"><svg xmlns="http://www.w3.org/2000/svg" class="_1l0elc" width="16" height="16" viewBox="0 0 20 16">
                                                <path d="M8.695 16.682C4.06 12.382 1 9.536 1 6.065 1 3.219 3.178 1 5.95 1c1.566 0 3.069.746 4.05 1.915C10.981 1.745 12.484 1 14.05 1 16.822 1 19 3.22 19 6.065c0 3.471-3.06 6.316-7.695 10.617L10 17.897l-1.305-1.215z" fill="#2874F0" class="eX72wL" stroke="#FFF" fill-rule="evenodd" opacity=".9"></path>
                                            </svg></div>
                                    </div>
                                </div>
                                <div class="_3pLy-c row">
                                    <div class="col col-7-12">
                                        <div class="_4rR01T">HP 27 inch Curved Full HD LED Backlit VA Panel Gaming Monitor (X27c)</div>
                                        <div class="gUuXy-"><span id="productRating_LSTMONG5H2QKVBZY6PSF4LUV6_MONG5H2QKVBZY6PS_" class="_1lRcqv">
                                                <div class="_3LWZlK">4.4<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                            </span><span class="_2_R_DZ"><span><span>94 Ratings&nbsp;</span><span class="_13vcmD">&amp;</span><span>&nbsp;20 Reviews</span></span></span></div>
                                        <div class="fMghEO">
                                            <ul class="_1xgFaf">
                                                <li class="rgWa7D">Panel Type: VA Panel</li>
                                                <li class="rgWa7D">Screen Resolution Type: Full HD</li>
                                                <li class="rgWa7D">Brightness: 350 nits</li>
                                                <li class="rgWa7D">Response Time: 1 ms | Refresh Rate: 165 Hz</li>
                                                <li class="rgWa7D">HDMI Ports - 1</li>
                                                <li class="rgWa7D">3 Years Warranty Provided by the Manufacturer from Date of Purchase</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col col-5-12 nlI3QM">
                                        <div class="_3tbKJL">
                                            <div class="_25b18c">
                                                <div class="_30jeq3 _1_WHN1">₹24,699</div>
                                                <div class="_3I9_wc _27UcVY">₹35,000</div>
                                                <div class="_3Ay6Sb"><span>29% off</span></div>
                                            </div>
                                            <div class="_3tcB5a p8ucoS">
                                                <div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-weight: 400;">Free delivery by</div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-style: normal; font-weight: 700;"> 29th Jun</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="_13J9qT"><img height="21" src="//static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png"></div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(38, 165, 65); font-size: 12px; font-weight: 700;">Hot Deal</div>
                                            </div>
                                        </div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;">Upto </div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 700;">₹220</div>
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(0, 0, 0); font-size: 14px; font-style: normal; font-weight: 400;"> Off on Exchange</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a></div>
                    </div>
                </div>
            </div>
            <div class="_1AtVbE col-12-12">
                <div class="_13oc-S">
                    <div data-id="MONGD4AF6HGGRHCT" style="width: 100%;">
                        <div class="_2kHMtA" data-tkid="1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONGD4AF6HGGRHCT.SEARCH"><a class="_1fQZEK" target="_blank" rel="noopener noreferrer" href="/zebronics-32-inch-curved-full-hd-va-panel-wall-mountable-monitor-zeb-ac32fhd-led/p/itmd0bf3471b1e6f?pid=MONGD4AF6HGGRHCT&amp;lid=LSTMONGD4AF6HGGRHCTBR05JC&amp;marketplace=FLIPKART&amp;store=6bo%2Fg0i%2F9no&amp;spotlightTagId=BestsellerId_6bo%2Fg0i%2F9no&amp;srno=b_1_14&amp;otracker=hp_omu_Top%2BOffers_3_4.dealCard.OMU_LNGPL5W28IL5_3&amp;otracker1=hp_omu_PINNED_neo%2Fmerchandising_Top%2BOffers_NA_dealCard_cc_3_NA_view-all_3&amp;fm=neo%2Fmerchandising&amp;iid=1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONGD4AF6HGGRHCT.SEARCH&amp;ppt=hp&amp;ppn=homepage&amp;ssid=2njax88o1c0000001687613497461">
                                <div></div>
                                <div class="MIXNux">
                                    <div class="_2QcLo-">
                                        <div>
                                            <div class="CXW8mj" style="height: 200px; width: 200px;"><img loading="eager" class="_396cs4" alt="ZEBRONICS 32 inch Curved Full HD VA Panel Wall Mountable Monitor (ZEB -AC32FHD LED)" src="https://rukminim1.flixcart.com/image/312/312/l3ahpjk0/monitor/a/v/q/-original-imagefsf8hkyuhdj.jpeg?q=70"></div>
                                        </div>
                                        <div class="_3G6awp"><span class="_192laR">Not deliverable</span></div>
                                    </div>
                                    <div class="_3wLduG"></div>
                                    <div class="_2hVSre _3nq8ih">
                                        <div class="_36FSn5"><svg xmlns="http://www.w3.org/2000/svg" class="_1l0elc" width="16" height="16" viewBox="0 0 20 16">
                                                <path d="M8.695 16.682C4.06 12.382 1 9.536 1 6.065 1 3.219 3.178 1 5.95 1c1.566 0 3.069.746 4.05 1.915C10.981 1.745 12.484 1 14.05 1 16.822 1 19 3.22 19 6.065c0 3.471-3.06 6.316-7.695 10.617L10 17.897l-1.305-1.215z" fill="#2874F0" class="eX72wL" stroke="#FFF" fill-rule="evenodd" opacity=".9"></path>
                                            </svg></div>
                                    </div>
                                </div>
                                <div class="_3pLy-c row">
                                    <div class="col col-7-12">
                                        <div class="_4rR01T">ZEBRONICS 32 inch Curved Full HD VA Panel Wall Mountable Monitor (ZEB -AC32FHD LED)</div>
                                        <div class="gUuXy-"><span id="productRating_LSTMONGD4AF6HGGRHCTBR05JC_MONGD4AF6HGGRHCT_" class="_1lRcqv">
                                                <div class="_3LWZlK">4.1<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                            </span><span class="_2_R_DZ"><span><span>863 Ratings&nbsp;</span><span class="_13vcmD">&amp;</span><span>&nbsp;115 Reviews</span></span></span></div>
                                        <div class="fMghEO">
                                            <ul class="_1xgFaf">
                                                <li class="rgWa7D">Panel Type: VA Panel</li>
                                                <li class="rgWa7D">Screen Resolution Type: Full HD</li>
                                                <li class="rgWa7D">VGA Support | HDMI</li>
                                                <li class="rgWa7D">Brightness: 250 nits</li>
                                                <li class="rgWa7D">Response Time: 8 ms | Refresh Rate: 75 Hz</li>
                                                <li class="rgWa7D">Three year carry into service centre</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col col-5-12 nlI3QM">
                                        <div class="_3tbKJL">
                                            <div class="_25b18c">
                                                <div class="_30jeq3 _1_WHN1">₹12,999</div>
                                                <div class="_3I9_wc _27UcVY">₹29,999</div>
                                                <div class="_3Ay6Sb"><span>56% off</span></div>
                                            </div>
                                            <div class="_3tcB5a p8ucoS">
                                                <div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-weight: 400;">Free delivery</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="_13J9qT"><img height="21" src="//static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png"></div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(38, 165, 65); font-size: 12px; font-weight: 700;">Daily Saver</div>
                                            </div>
                                        </div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(38, 165, 65); font-size: 14px; font-weight: 700;">Bank Offer</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a></div>
                    </div>
                </div>
            </div>
            <div class="_1AtVbE col-12-12">
                <div class="_13oc-S">
                    <div data-id="MONGAYHG97KGYYWX" style="width: 100%;">
                        <div class="_2kHMtA" data-tkid="1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONGAYHG97KGYYWX.SEARCH"><a class="_1fQZEK" target="_blank" rel="noopener noreferrer" href="/marq-flipkart-32-inch-curved-full-hd-led-backlit-va-panel-2-x-3w-inbuilt-speakers-gaming-monitor-32fhdmcqii1g/p/itmc3a5f6a8c621e?pid=MONGAYHG97KGYYWX&amp;lid=LSTMONGAYHG97KGYYWXNTWARL&amp;marketplace=FLIPKART&amp;store=6bo%2Fg0i%2F9no&amp;spotlightTagId=TrendingId_6bo%2Fg0i%2F9no&amp;srno=b_1_15&amp;otracker=hp_omu_Top%2BOffers_3_4.dealCard.OMU_LNGPL5W28IL5_3&amp;otracker1=hp_omu_PINNED_neo%2Fmerchandising_Top%2BOffers_NA_dealCard_cc_3_NA_view-all_3&amp;fm=neo%2Fmerchandising&amp;iid=1b8fc128-3ded-45c7-b3cc-226d6112e9f0.MONGAYHG97KGYYWX.SEARCH&amp;ppt=hp&amp;ppn=homepage&amp;ssid=2njax88o1c0000001687613497461">
                                <div></div>
                                <div class="MIXNux">
                                    <div class="_2QcLo-">
                                        <div>
                                            <div class="CXW8mj" style="height: 200px; width: 200px;"><img loading="eager" class="_396cs4" alt="MarQ by Flipkart 32 inch Curved Full HD LED Backlit VA Panel with 2 X 3W Inbuilt Speakers Gaming Monit..." src="https://rukminim1.flixcart.com/image/312/312/l3t2fm80/monitor/n/s/9/-original-imageudy57eywqdy.jpeg?q=70"></div>
                                        </div>
                                        <div class="_3G6awp"><span class="_192laR">Not deliverable</span></div>
                                    </div>
                                    <div class="_3wLduG"></div>
                                    <div class="_2hVSre _3nq8ih">
                                        <div class="_36FSn5"><svg xmlns="http://www.w3.org/2000/svg" class="_1l0elc" width="16" height="16" viewBox="0 0 20 16">
                                                <path d="M8.695 16.682C4.06 12.382 1 9.536 1 6.065 1 3.219 3.178 1 5.95 1c1.566 0 3.069.746 4.05 1.915C10.981 1.745 12.484 1 14.05 1 16.822 1 19 3.22 19 6.065c0 3.471-3.06 6.316-7.695 10.617L10 17.897l-1.305-1.215z" fill="#2874F0" class="eX72wL" stroke="#FFF" fill-rule="evenodd" opacity=".9"></path>
                                            </svg></div>
                                    </div>
                                </div>
                                <div class="_3pLy-c row">
                                    <div class="col col-7-12">
                                        <div class="_4rR01T">MarQ by Flipkart 32 inch Curved Full HD LED Backlit VA Panel with 2 X 3W Inbuilt Speakers Gaming Monit...</div>
                                        <div class="gUuXy-"><span id="productRating_LSTMONGAYHG97KGYYWXNTWARL_MONGAYHG97KGYYWX_" class="_1lRcqv">
                                                <div class="_3LWZlK">4.4<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                            </span><span class="_2_R_DZ"><span><span>240 Ratings&nbsp;</span><span class="_13vcmD">&amp;</span><span>&nbsp;43 Reviews</span></span></span></div>
                                        <div class="fMghEO">
                                            <ul class="_1xgFaf">
                                                <li class="rgWa7D">Panel Type: VA Panel</li>
                                                <li class="rgWa7D">Screen Resolution Type: Full HD</li>
                                                <li class="rgWa7D">Brightness: 300 nits</li>
                                                <li class="rgWa7D">Response Time: 5 ms | Refresh Rate: 165 Hz</li>
                                                <li class="rgWa7D">1 Year Warranty from the Date of Purchase</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col col-5-12 nlI3QM">
                                        <div class="_3tbKJL">
                                            <div class="_25b18c">
                                                <div class="_30jeq3 _1_WHN1">₹14,299</div>
                                                <div class="_3I9_wc _27UcVY">₹25,999</div>
                                                <div class="_3Ay6Sb"><span>45% off</span></div>
                                            </div>
                                            <div class="_3tcB5a p8ucoS">
                                                <div>
                                                    <div class="_2Tpdn3" style="color: rgb(0, 0, 0); font-size: 12px; font-weight: 400;">Free delivery</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="_13J9qT"><img height="21" src="//static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png"></div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(38, 165, 65); font-size: 12px; font-weight: 700;">Daily Saver</div>
                                            </div>
                                        </div>
                                        <div class="_2ZdXDB">
                                            <div class="_3xFhiH">
                                                <div class="_2Tpdn3 _18hQoS" style="color: rgb(38, 165, 65); font-size: 14px; font-weight: 700;">Bank Offer</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a></div>
                    </div>
                </div>
            </div>
            <div class="_1AtVbE col-12-12" style="margin: 10px 0px 0px;">
                <div class="_1anD2T" data-tkid="1b8fc128-3ded-45c7-b3cc-226d6112e9f0"><span class="PTpXCl">Did you find what you were looking for?</span>
                    <div class="_1ye8x2 _1xLf4B"><span class="_2eFmU2 _3ZMjMT">Yes</span><span class="_2eFmU2 _3ZMjMT">No</span></div>
                </div>
            </div>
        </div>
    </div>
    <div class="_1AtVbE col-12-12" style="padding: 16px 0px 0px;">
        <div class="_3E8aIl X3IECw row">
            <div class="_88-NUv">Reviews for Popular Curved Monitors</div>
            <div class="_2nRPpA">
                <div class="_1Ni40J">
                    <div class="_3hVUcF">
                        <div class="CXW8mj" style="height: 150px; width: 150px;"><img loading="lazy" class="_396cs4" alt="MSI 27 inch Curved Full HD LED Backlit VA Panel Frameless, with Adjustable Stand, Anti-Flicker &amp; Less Blue Light Gaming Monitor (Optix G27C5)" src="https://rukminim1.flixcart.com/image/300/300/l0cr4i80/monitor/m/y/v/optix-g27c5-full-hd-27-9s6-3ca91t-047-msi-original-imagc63qhkwzymj6.jpeg?q=90"></div>
                    </div>
                    <div class="_1kLt05"><a target="_blank" rel="noopener noreferrer" href="/msi-27-inch-curved-full-hd-led-backlit-va-panel-frameless-adjustable-stand-anti-flicker-less-blue-light-gaming-monitor-optix-g27c5/p/itm066d7068d3bad?pid=MONGC4PWUBVGHZYG&amp;marketplace=FLIPKART">
                            <div class="_1W9f5C">
                                <div>1. MSI 27 inch Curved Full HD ...</div>
                            </div>
                            <div class="_3VDxyD">
                                <div class="_3LWZlK">4.1<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div><span class="_34hpFu"><span>9 Ratings</span><span><span class="_2oY1qB">&amp;</span><span>1 Reviews</span></span></span>
                            </div>
                            <div class="_2wYYVP">
                                <div class="_25b18c">
                                    <div class="_30jeq3 UMT9wN">₹21,399</div>
                                    <div class="_3Ay6Sb _2FuKQX"><span>36% off</span></div>
                                </div>
                            </div>
                        </a>
                        <ul class="_1Sq2Fs">
                            <li class="_2OosNL">Panel Type: VA Panel</li>
                            <li class="_2OosNL">Screen Resolution Type: Full HD</li>
                            <li class="_2OosNL">Brightness: 250 nits</li>
                        </ul>
                    </div>
                </div>
                <div class="_2tzWk4">
                    <div class="_1A_Aux">Most Helpful Review</div>
                    <div class="col">
                        <div class="col _2wzgFH _2cVXgz">
                            <div class="row">
                                <div class="_3LWZlK _1BLPMq">4<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                <p class="_2-N8zT">Nice product</p>
                            </div>
                            <div class="row">
                                <div class="t-ZTKy">
                                    <div>
                                        <div class="">Nice 👍</div><span class="_1H-bmy"><span>Read full review</span></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row _3n8db9">
                                <div class="row">
                                    <p class="_2sc7ZR _2V5EHH">Laddu babu </p><svg width="14" height="14" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg" class="_2a1p_T">
                                        <g>
                                            <circle cx="6" cy="6" r="6" fill="#878787"></circle>
                                            <path stroke="#FFF" stroke-width="1.5" d="M3 6l2 2 4-4" fill="#878787"></path>
                                        </g>
                                    </svg>
                                    <p id="review-45990813-ac03-4dea-979d-02c21a6d5374" class="_2mcZGG"><span>Certified Buyer</span></p>
                                    <p class="_2sc7ZR">10 months ago</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="_2tzWk4">
                    <div class="_1A_Aux">Recent Review</div>
                    <div class="col">
                        <div class="col _2wzgFH _2cVXgz">
                            <div class="row">
                                <div class="_3LWZlK _1BLPMq">4<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                <p class="_2-N8zT">Nice product</p>
                            </div>
                            <div class="row">
                                <div class="t-ZTKy">
                                    <div>
                                        <div class="">Nice 👍</div><span class="_1H-bmy"><span>Read full review</span></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row _3n8db9">
                                <div class="row">
                                    <p class="_2sc7ZR _2V5EHH">Laddu babu </p><svg width="14" height="14" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg" class="_2a1p_T">
                                        <g>
                                            <circle cx="6" cy="6" r="6" fill="#878787"></circle>
                                            <path stroke="#FFF" stroke-width="1.5" d="M3 6l2 2 4-4" fill="#878787"></path>
                                        </g>
                                    </svg>
                                    <p id="review-45990813-ac03-4dea-979d-02c21a6d5374" class="_2mcZGG"><span>Certified Buyer</span></p>
                                    <p class="_2sc7ZR">10 months ago</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="_2nRPpA">
                <div class="_1Ni40J">
                    <div class="_3hVUcF">
                        <div class="CXW8mj" style="height: 150px; width: 150px;"><img loading="lazy" class="_396cs4" alt="SAMSUNG 23.8 inch Curved Full HD LED Backlit VA Panel with 1800R, HDMI, Audio Ports, HDMI, Flicker Free Slim Design Monitor (LC24F390FHWXXL/LS24C360EAWXXL)" src="https://rukminim1.flixcart.com/image/300/300/xif0q/monitor/5/t/s/-original-imagppc6tyfe3jxf.jpeg?q=90"></div>
                    </div>
                    <div class="_1kLt05"><a target="_blank" rel="noopener noreferrer" href="/samsung-23-8-inch-curved-full-hd-led-backlit-va-panel-1800r-hdmi-audio-ports-flicker-free-slim-design-monitor-lc24f390fhwxxl-ls24c360eawxxl/p/itm1590d895ebc96?pid=MONEZU4Z8BYBV2GZ&amp;marketplace=FLIPKART">
                            <div class="_1W9f5C">
                                <div>2. SAMSUNG 23.8 inch Curved Fu...</div>
                            </div>
                            <div class="_3VDxyD">
                                <div class="_3LWZlK">4.5<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div><span class="_34hpFu"><span>3,289 Ratings</span><span><span class="_2oY1qB">&amp;</span><span>545 Reviews</span></span></span>
                            </div>
                            <div class="_2wYYVP">
                                <div class="_25b18c">
                                    <div class="_30jeq3 UMT9wN">₹9,499</div>
                                    <div class="_3Ay6Sb _2FuKQX"><span>42% off</span></div>
                                </div>
                            </div>
                        </a>
                        <ul class="_1Sq2Fs">
                            <li class="_2OosNL">Panel Type: VA Panel</li>
                            <li class="_2OosNL">Screen Resolution Type: Full HD</li>
                            <li class="_2OosNL">VGA Support | HDMI</li>
                        </ul>
                    </div>
                </div>
                <div class="_2tzWk4">
                    <div class="_1A_Aux">Most Helpful Review</div>
                    <div class="col">
                        <div class="col _2wzgFH _2cVXgz">
                            <div class="row">
                                <div class="_3LWZlK _1BLPMq">5<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                <p class="_2-N8zT">Amazing Display</p>
                            </div>
                            <div class="row">
                                <div class="t-ZTKy">
                                    <div>
                                        <div class="">This monitor is just awesome. Amazing picture quality. I can do coding and watch anime's for whole day and night.<br>It is also good for eyes. No reflections at...</div><span class="_1BWGvX"><span>Read full review</span></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row _3n8db9">
                                <div class="row">
                                    <p class="_2sc7ZR _2V5EHH">Amit Dongarwar</p><svg width="14" height="14" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg" class="_2a1p_T">
                                        <g>
                                            <circle cx="6" cy="6" r="6" fill="#878787"></circle>
                                            <path stroke="#FFF" stroke-width="1.5" d="M3 6l2 2 4-4" fill="#878787"></path>
                                        </g>
                                    </svg>
                                    <p id="review-e6a732df-095a-4016-8f99-9fec96e480ba" class="_2mcZGG"><span>Certified Buyer</span></p>
                                    <p class="_2sc7ZR">Feb, 2021</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="_2tzWk4">
                    <div class="_1A_Aux">Recent Review</div>
                    <div class="col">
                        <div class="col _2wzgFH _2cVXgz">
                            <div class="row">
                                <div class="_3LWZlK _1rdVr6 _1BLPMq">1<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                <p class="_2-N8zT">Hated it!</p>
                            </div>
                            <div class="row">
                                <div class="t-ZTKy">
                                    <div>
                                        <div class="">60 hz Not Good sumsung 24inch moniter 75hz good</div><span class="_1H-bmy"><span>Read full review</span></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row _3n8db9">
                                <div class="row">
                                    <p class="_2sc7ZR _2V5EHH">Flipkart Customer</p><svg width="14" height="14" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg" class="_2a1p_T">
                                        <g>
                                            <circle cx="6" cy="6" r="6" fill="#878787"></circle>
                                            <path stroke="#FFF" stroke-width="1.5" d="M3 6l2 2 4-4" fill="#878787"></path>
                                        </g>
                                    </svg>
                                    <p id="review-631d09a1-e7bb-4ebb-97b8-d85c2a0b393b" class="_2mcZGG"><span>Certified Buyer</span></p>
                                    <p class="_2sc7ZR">14 days ago</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="_2nRPpA">
                <div class="_1Ni40J">
                    <div class="_3hVUcF">
                        <div class="CXW8mj" style="height: 150px; width: 150px;"><img loading="lazy" class="_396cs4" alt="Acer HC1 27 inch Curved Full HD VA Panel Gaming Monitor (27HC1R)" src="https://rukminim1.flixcart.com/image/300/300/ksoz53k0/monitor/m/x/q/27hc1r-full-hd-27-um-hw1si-p01-acer-original-imag67pqaf6zbgrz.jpeg?q=90"></div>
                    </div>
                    <div class="_1kLt05"><a target="_blank" rel="noopener noreferrer" href="/acer-hc1-27-inch-curved-full-hd-va-panel-gaming-monitor-27hc1r/p/itm1cdbf40857dff?pid=MONG5ZV3Q2QKSMDD&amp;marketplace=FLIPKART">
                            <div class="_1W9f5C">
                                <div>3. Acer HC1 27 inch Curved Ful...</div>
                            </div>
                            <div class="_3VDxyD">
                                <div class="_3LWZlK">4.1<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div><span class="_34hpFu"><span>58 Ratings</span><span><span class="_2oY1qB">&amp;</span><span>8 Reviews</span></span></span>
                            </div>
                            <div class="_2wYYVP">
                                <div class="_25b18c">
                                    <div class="_30jeq3 UMT9wN">₹18,999</div>
                                    <div class="_3Ay6Sb _2FuKQX"><span>55% off</span></div>
                                </div>
                            </div>
                        </a>
                        <ul class="_1Sq2Fs">
                            <li class="_2OosNL">Panel Type: VA Panel</li>
                            <li class="_2OosNL">Screen Resolution Type: Full HD</li>
                            <li class="_2OosNL">Response Time: 4 ms | Refresh Rate: 144 Hz</li>
                        </ul>
                    </div>
                </div>
                <div class="_2tzWk4">
                    <div class="_1A_Aux">Most Helpful Review</div>
                    <div class="col">
                        <div class="col _2wzgFH _2cVXgz">
                            <div class="row">
                                <div class="_3LWZlK _1BLPMq">4<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                <p class="_2-N8zT">Pretty good</p>
                            </div>
                            <div class="row">
                                <div class="t-ZTKy">
                                    <div>
                                        <div class="">It's amazing really super in budget impressive</div><span class="_1H-bmy"><span>Read full review</span></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row _3n8db9">
                                <div class="row">
                                    <p class="_2sc7ZR _2V5EHH">deepak Yogi</p><svg width="14" height="14" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg" class="_2a1p_T">
                                        <g>
                                            <circle cx="6" cy="6" r="6" fill="#878787"></circle>
                                            <path stroke="#FFF" stroke-width="1.5" d="M3 6l2 2 4-4" fill="#878787"></path>
                                        </g>
                                    </svg>
                                    <p id="review-8d62459b-f6d5-4f22-98a7-3d016d28cca9" class="_2mcZGG"><span>Certified Buyer</span></p>
                                    <p class="_2sc7ZR">11 months ago</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="_2tzWk4">
                    <div class="_1A_Aux">Recent Review</div>
                    <div class="col">
                        <div class="col _2wzgFH _2cVXgz">
                            <div class="row">
                                <div class="_3LWZlK _1BLPMq">4<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                <p class="_2-N8zT">Pretty good</p>
                            </div>
                            <div class="row">
                                <div class="t-ZTKy">
                                    <div>
                                        <div class="">It's amazing really super in budget impressive</div><span class="_1H-bmy"><span>Read full review</span></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row _3n8db9">
                                <div class="row">
                                    <p class="_2sc7ZR _2V5EHH">deepak Yogi</p><svg width="14" height="14" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg" class="_2a1p_T">
                                        <g>
                                            <circle cx="6" cy="6" r="6" fill="#878787"></circle>
                                            <path stroke="#FFF" stroke-width="1.5" d="M3 6l2 2 4-4" fill="#878787"></path>
                                        </g>
                                    </svg>
                                    <p id="review-8d62459b-f6d5-4f22-98a7-3d016d28cca9" class="_2mcZGG"><span>Certified Buyer</span></p>
                                    <p class="_2sc7ZR">11 months ago</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="_2nRPpA">
                <div class="_1Ni40J">
                    <div class="_3hVUcF">
                        <div class="CXW8mj" style="height: 150px; width: 150px;"><img loading="lazy" class="_396cs4" alt="Acer 23.6 inch Curved Full HD VA Panel with VESA Mount Support, 1500R Curvature, HDMI 1.4, Integrated Speakers Gaming Monitor (ED240Q)" src="https://rukminim1.flixcart.com/image/300/300/xif0q/monitor/r/5/v/-original-imaggd38vfwc6h7v.jpeg?q=90"></div>
                    </div>
                    <div class="_1kLt05"><a target="_blank" rel="noopener noreferrer" href="/acer-23-6-inch-curved-full-hd-va-panel-vesa-mount-support-1500r-curvature-hdmi-1-4-integrated-speakers-gaming-monitor-ed240q/p/itm30fe5e5a30da7?pid=MONGHYDYGZVXTBS9&amp;marketplace=FLIPKART">
                            <div class="_1W9f5C">
                                <div>4. Acer 23.6 inch Curved Full ...</div>
                            </div>
                            <div class="_3VDxyD">
                                <div class="_3LWZlK">4.4<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div><span class="_34hpFu"><span>895 Ratings</span><span><span class="_2oY1qB">&amp;</span><span>136 Reviews</span></span></span>
                            </div>
                            <div class="_2wYYVP">
                                <div class="_25b18c">
                                    <div class="_30jeq3 UMT9wN">₹8,299</div>
                                    <div class="_3Ay6Sb _2FuKQX"><span>17% off</span></div>
                                </div>
                            </div>
                        </a>
                        <ul class="_1Sq2Fs">
                            <li class="_2OosNL">Panel Type: VA Panel</li>
                            <li class="_2OosNL">Screen Resolution Type: Full HD</li>
                            <li class="_2OosNL">Brightness: 250 nits</li>
                        </ul>
                    </div>
                </div>
                <div class="_2tzWk4">
                    <div class="_1A_Aux">Most Helpful Review</div>
                    <div class="col">
                        <div class="col _2wzgFH _2cVXgz">
                            <div class="row">
                                <div class="_3LWZlK _1BLPMq">5<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                <p class="_2-N8zT">Simply awesome</p>
                            </div>
                            <div class="row">
                                <div class="t-ZTKy">
                                    <div>
                                        <div class="">This is the Best Curved Gaming Monitor Ever at this Price!! 🤯 ( It's LCD but More Worth it 👍 ) <br>It gives you AMD VSYNC, 70Hz Refresh Rate , FHD 1090x1080 d...</div><span class="_1BWGvX"><span>Read full review</span></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row _3n8db9">
                                <div class="row">
                                    <p class="_2sc7ZR _2V5EHH">Harsimran Kaur</p><svg width="14" height="14" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg" class="_2a1p_T">
                                        <g>
                                            <circle cx="6" cy="6" r="6" fill="#878787"></circle>
                                            <path stroke="#FFF" stroke-width="1.5" d="M3 6l2 2 4-4" fill="#878787"></path>
                                        </g>
                                    </svg>
                                    <p id="review-c79525fa-1fb7-405a-b12b-84c2f70019c9" class="_2mcZGG"><span>Certified Buyer</span></p>
                                    <p class="_2sc7ZR">7 months ago</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="_2tzWk4">
                    <div class="_1A_Aux">Recent Review</div>
                    <div class="col">
                        <div class="col _2wzgFH _2cVXgz">
                            <div class="row">
                                <div class="_3LWZlK _1rdVr6 _1BLPMq">1<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                <p class="_2-N8zT">Waste of money!</p>
                            </div>
                            <div class="row">
                                <div class="t-ZTKy">
                                    <div>
                                        <div class="">In second horizontal line showing in display always</div><span class="_1H-bmy"><span>Read full review</span></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row _3n8db9">
                                <div class="row">
                                    <p class="_2sc7ZR _2V5EHH">Vignesh Ms</p><svg width="14" height="14" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg" class="_2a1p_T">
                                        <g>
                                            <circle cx="6" cy="6" r="6" fill="#878787"></circle>
                                            <path stroke="#FFF" stroke-width="1.5" d="M3 6l2 2 4-4" fill="#878787"></path>
                                        </g>
                                    </svg>
                                    <p id="review-032af3fa-bdcc-4feb-af0f-ffb6991a76da" class="_2mcZGG"><span>Certified Buyer</span></p>
                                    <p class="_2sc7ZR">4 days ago</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="_2nRPpA">
                <div class="_1Ni40J">
                    <div class="_3hVUcF">
                        <div class="CXW8mj" style="height: 150px; width: 150px;"><img loading="lazy" class="_396cs4" alt="MSI Optix 27 inch Curved Full HD VA Panel Gaming Monitor (Optix G27C4)" src="https://rukminim1.flixcart.com/image/300/300/ksru0sw0/monitor/c/f/j/optix-g27c4-full-hd-optix-g27c4-msi-original-imag69gbqqcqq9eb.jpeg?q=90"></div>
                    </div>
                    <div class="_1kLt05"><a target="_blank" rel="noopener noreferrer" href="/msi-optix-27-inch-curved-full-hd-va-panel-gaming-monitor-optix-g27c4/p/itm62346f3bd253d?pid=MONFZZYGFX8XYS7G&amp;marketplace=FLIPKART">
                            <div class="_1W9f5C">
                                <div>5. MSI Optix 27 inch Curved Fu...</div>
                            </div>
                            <div class="_3VDxyD">
                                <div class="_3LWZlK">4.2<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div><span class="_34hpFu"><span>31 Ratings</span><span><span class="_2oY1qB">&amp;</span><span>6 Reviews</span></span></span>
                            </div>
                            <div class="_2wYYVP">
                                <div class="_25b18c">
                                    <div class="_30jeq3 UMT9wN">₹18,699</div>
                                    <div class="_3Ay6Sb _2FuKQX"><span>44% off</span></div>
                                </div>
                            </div>
                        </a>
                        <ul class="_1Sq2Fs">
                            <li class="_2OosNL">Panel Type: VA Panel</li>
                            <li class="_2OosNL">Screen Resolution Type: Full HD</li>
                            <li class="_2OosNL">Brightness: 250 nits</li>
                        </ul>
                    </div>
                </div>
                <div class="_2tzWk4">
                    <div class="_1A_Aux">Most Helpful Review</div>
                    <div class="col">
                        <div class="col _2wzgFH _2cVXgz">
                            <div class="row">
                                <div class="_3LWZlK _1BLPMq">3<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                <p class="_2-N8zT">Just okay</p>
                            </div>
                            <div class="row">
                                <div class="t-ZTKy">
                                    <div>
                                        <div class="">Only one I can tell <br>Picture quality was not clarity<br>And <br><br>Working <br>Good..! <br><br>17552 price ..!</div><span class="_1H-bmy"><span>Read full review</span></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row _3n8db9">
                                <div class="row">
                                    <p class="_2sc7ZR _2V5EHH">Raj Kumar Polavarapu</p><svg width="14" height="14" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg" class="_2a1p_T">
                                        <g>
                                            <circle cx="6" cy="6" r="6" fill="#878787"></circle>
                                            <path stroke="#FFF" stroke-width="1.5" d="M3 6l2 2 4-4" fill="#878787"></path>
                                        </g>
                                    </svg>
                                    <p id="review-dcdca4cb-103a-4161-899f-5ef11d208835" class="_2mcZGG"><span>Certified Buyer</span></p>
                                    <p class="_2sc7ZR">Nov, 2021</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="_2tzWk4">
                    <div class="_1A_Aux">Recent Review</div>
                    <div class="col">
                        <div class="col _2wzgFH _2cVXgz">
                            <div class="row">
                                <div class="_3LWZlK _1rdVr6 _1BLPMq">1<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
                                <p class="_2-N8zT">Hated it!</p>
                            </div>
                            <div class="row">
                                <div class="t-ZTKy">
                                    <div>
                                        <div class="">Too much ghosting.... And i am facing screen flickering problem... Not good at all</div><span class="_1H-bmy"><span>Read full review</span></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row _3n8db9">
                                <div class="row">
                                    <p class="_2sc7ZR _2V5EHH">Piyush Kumar</p><svg width="14" height="14" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg" class="_2a1p_T">
                                        <g>
                                            <circle cx="6" cy="6" r="6" fill="#878787"></circle>
                                            <path stroke="#FFF" stroke-width="1.5" d="M3 6l2 2 4-4" fill="#878787"></path>
                                        </g>
                                    </svg>
                                    <p id="review-58e1be5e-3bc3-479e-a4b1-941ec1fc0883" class="_2mcZGG"><span>Certified Buyer</span></p>
                                    <p class="_2sc7ZR">8 months ago</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="_1AtVbE col-12-12"></div>
</div>

</body>
</html>